#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# paper-cycle.sh — run the desk's paper-trading cycle.
#
#   bash scripts/paper-cycle.sh                    # one cycle, default settings
#   bash scripts/paper-cycle.sh --strategy sma-crossover --interval 240
#   bash scripts/paper-cycle.sh --loop 60          # repeat every 60 minutes
#   bash scripts/paper-cycle.sh --reset            # start a fresh paper record
#
# It pulls live candles from Kraken's PUBLIC API (no key, no account access),
# runs the strategy through the real engine, logs closed paper trades to the
# append-only ledger, and rewrites the paper status file.
#
# It cannot place an order. There is no code path from here to an exchange.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENGINE="$ROOT/workspaces/engine"

if ! command -v node >/dev/null 2>&1; then
  echo "node is not on PATH — Paperclip needs Node 24+ (Termux: pkg install nodejs-lts)" >&2
  exit 1
fi

cd "$ENGINE" || exit 1

# Sensible defaults if the caller didn't specify any
HAS_STRATEGY=0
HAS_PAIR=0
for a in "$@"; do
  case "$a" in
    --strategy|--strategy=*) HAS_STRATEGY=1 ;;
    --pair|--pair=*) HAS_PAIR=1 ;;
  esac
done

ARGS=()
[ "$HAS_STRATEGY" -eq 0 ] && ARGS+=(--strategy sma-crossover)
[ "$HAS_PAIR" -eq 0 ] && ARGS+=(--pair XRPUSD)
[ $# -eq 0 ] && ARGS+=(--interval 60 --equity 250)

exec node src/cli.js paper "${ARGS[@]}" "$@"
