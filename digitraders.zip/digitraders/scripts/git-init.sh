#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# git-init.sh — turn each workspaces/* folder into a git repo that Paperclip
# can use for isolated per-issue worktrees.
#
#   bash scripts/git-init.sh
#   bash scripts/git-init.sh --remote core https://github.com/you/core.git
#
# Paperclip's `git_worktree` execution policy creates one worktree per issue,
# branched off `main`. That only works if this folder is already a git repo
# with a `main` branch.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REMOTE_KEY=""
REMOTE_URL=""

while [ $# -gt 0 ]; do
  case "$1" in
    --remote) REMOTE_KEY="${2:-}"; REMOTE_URL="${3:-}"; shift 3 ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

if ! command -v git >/dev/null 2>&1; then
  echo "git is not installed." >&2
  exit 1
fi

for d in "$ROOT"/workspaces/*/; do
  [ -d "$d" ] || continue
  name=$(basename "$d")

  # Android shared storage doesn't preserve Unix permission bits, and its files
  # are owned by another UID — both make git misbehave. Fix both there only.
  if printf '%s' "$d" | grep -qE '/storage/(shared|emulated|[0-9A-Fa-f-]+)'; then
    git config --global core.fileMode false
    git config --global --add safe.directory '*'
  fi

  if [ -d "$d/.git" ]; then
    echo "✓ $name — already a git repo"
  else
    git -C "$d" init -q -b main 2>/dev/null || {
      git -C "$d" init -q
      git -C "$d" symbolic-ref HEAD refs/heads/main
    }
    printf 'node_modules/\ndist/\n.env\n.env.*\n!.env.example\n' > "$d/.gitignore"
    echo "✓ $name — initialised git repo on main"
  fi

  # make sure a commit exists (worktrees need a real HEAD)
  if ! git -C "$d" rev-parse HEAD >/dev/null 2>&1; then
    echo "# $name" > "$d/README.md"
    git -C "$d" add -A
    git -C "$d" -c user.email="agent@local" -c user.name="paperclip bootstrap" commit -q -m "chore: initialise $name workspace" || true
    echo "  · created first commit"
  fi

  # optional remote
  if [ "$REMOTE_KEY" = "$name" ] && [ -n "$REMOTE_URL" ]; then
    if git -C "$d" remote get-url origin >/dev/null 2>&1; then
      git -C "$d" remote set-url origin "$REMOTE_URL"
      echo "  · origin → $REMOTE_URL"
    else
      git -C "$d" remote add origin "$REMOTE_URL"
      echo "  · added origin → $REMOTE_URL"
    fi
  fi
done

echo
echo "Next: attach your GitHub repo, e.g."
echo "  bash scripts/git-init.sh --remote core https://github.com/<you>/<repo>.git"
