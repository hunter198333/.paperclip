#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# position-size.sh — size a trade, then check it against the risk policy.
#
#   bash scripts/position-size.sh --equity 250 --entry 1.85 --stop 1.78
#   bash scripts/position-size.sh --equity 250 --entry 0.62 --stop 0.60 --edge 3.5
#
# Optional:
#   --risk PCT      risk per trade as % of equity        (default 0.5 — policy L1)
#   --edge PCT      expected GROSS edge per trade in %   (needed for the L13 check)
#   --min-size N    Kraken minimum order size for the pair (units)
#   --maker PCT     maker fee %  (default 0.40 — Kraken Tier 1)
#   --taker PCT     taker fee %  (default 0.80 — Kraken Tier 1)
#
# Read-only calculator. It sizes, it checks, it never trades.
# ---------------------------------------------------------------------------
set -uo pipefail

EQUITY=""; ENTRY=""; STOP=""; RISK="0.5"; EDGE=""; MIN_SIZE=""
MAKER="0.40"; TAKER="0.80"

while [ $# -gt 0 ]; do
  case "$1" in
    --equity)   EQUITY="${2:-}"; shift 2 ;;
    --entry)    ENTRY="${2:-}";  shift 2 ;;
    --stop)     STOP="${2:-}";   shift 2 ;;
    --risk)     RISK="${2:-}";   shift 2 ;;
    --edge)     EDGE="${2:-}";   shift 2 ;;
    --min-size) MIN_SIZE="${2:-}"; shift 2 ;;
    --maker)    MAKER="${2:-}";  shift 2 ;;
    --taker)    TAKER="${2:-}";  shift 2 ;;
    -h|--help)  sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

if [ -z "$EQUITY" ] || [ -z "$ENTRY" ] || [ -z "$STOP" ]; then
  echo "usage: bash scripts/position-size.sh --equity E --entry P --stop P [--risk PCT] [--edge PCT]" >&2
  exit 2
fi

awk -v eq="$EQUITY" -v entry="$ENTRY" -v stop="$STOP" -v risk="$RISK" \
    -v edge="$EDGE" -v minsz="$MIN_SIZE" -v maker="$MAKER" -v taker="$TAKER" '
function f(x,  d) { d = (x == int(x)) ? 2 : 6; return sprintf("%." d "f", x) }
function pct(x) { return sprintf("%.2f%%", x) }
BEGIN {
  if (eq <= 0 || entry <= 0) { print "equity and entry must be > 0"; exit 1 }

  dist   = (entry > stop) ? entry - stop : stop - entry
  if (dist <= 0) { print "entry and stop must differ"; exit 1 }

  risk_amt  = eq * risk / 100
  size      = risk_amt / dist
  notional  = size * entry
  risk_pct  = (dist * size) / eq * 100

  fee_maker = notional * maker / 100 * 2
  fee_taker = notional * taker / 100 * 2
  fee_m_pct = fee_maker / eq * 100
  fee_t_pct = fee_taker / eq * 100

  # L13: round-trip fees must be <= 25% of expected gross edge
  min_edge_maker = fee_m_pct / 0.25
  min_edge_taker = fee_t_pct / 0.25

  print "=========================================================="
  print " POSITION SIZING"
  print "=========================================================="
  printf " Equity                 %14.4f\n", eq
  printf " Entry                  %14.6f\n", entry
  printf " Stop                   %14.6f\n", stop
  printf " Distance to stop       %14.6f  (%.4f%%)\n", dist, dist/entry*100
  print "----------------------------------------------------------"
  printf " Risk per trade (L1)    %14s\n", pct(risk)
  printf " Risk amount            %14.4f\n", risk_amt
  printf " Size (units)           %14.8f\n", size
  printf " Notional               %14.4f\n", notional
  printf " Notional %% of equity   %14s\n", pct(notional/eq*100)
  print "----------------------------------------------------------"
  printf " Fees maker (L15)       %14.4f   (%s of equity)\n", fee_maker, pct(fee_m_pct)
  printf " Fees taker (rejected)  %14.4f   (%s of equity)\n", fee_taker, pct(fee_t_pct)
  print "----------------------------------------------------------"

  fail = 0

  # L1
  if (risk_pct <= risk + 0.0001) printf " [PASS] L1  risk %.4f%% <= %.2f%%\n", risk_pct, risk
  else { printf " [FAIL] L1  risk %.4f%% > %.2f%%\n", risk_pct, risk; fail = 1 }

  # L6 — max single position notional 25% of equity
  if (notional/eq*100 <= 25.0001) printf " [PASS] L6  notional %s of equity <= 25%%\n", pct(notional/eq*100)
  else { printf " [WARN] L6  notional %s of equity > 25%% — split or shrink\n", pct(notional/eq*100); fail = 1 }

  # L13 — cost-to-edge
  if (edge != "") {
    if (fee_m_pct <= edge * 0.25 + 0.0001)
      printf " [PASS] L13 fees %s <= 25%% of gross edge %s\n", pct(fee_m_pct), pct(edge)
    else {
      printf " [FAIL] L13 fees %s > 25%% of gross edge %s\n", pct(fee_m_pct), pct(edge)
      printf "        needed gross edge: %s (maker) / %s (taker)\n", pct(min_edge_maker), pct(min_edge_taker)
      fail = 1
    }
  } else {
    printf " [ ?  ] L13 no --edge given. Minimum gross edge needed: %s (maker)\n", pct(min_edge_maker)
    printf "        %s (taker). Below this, the trade loses money even if the signal is right.\n", pct(min_edge_taker)
  }

  # Kraken minimum order size
  if (minsz != "") {
    if (size + 0.000000001 >= minsz)
      printf " [PASS] size %s >= Kraken minimum %s\n", f(size, 8), f(minsz, 8)
    else {
      printf " [FAIL] size %s < Kraken minimum order size %s — do not trade this pair\n", f(size, 8), f(minsz, 8)
      fail = 1
    }
  }

  print "----------------------------------------------------------"
  if (fail) print " RESULT: BLOCKED — do not propose this trade."
  else      print " RESULT: clears the checks above. Still needs a proposal + approval."
  print "=========================================================="
  exit (fail ? 1 : 0)
}
'
