#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# sync.sh — keep the phone and the PC in sync through git.
#
#   bash scripts/sync.sh pull     # fetch the latest from GitHub (PC side)
#   bash scripts/sync.sh push     # commit + push local changes
#   bash scripts/sync.sh cycle    # pull, run the paper cycle, commit, push
#
# Run the cycle on ONE machine only (the PC). The other side reads.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE="${1:-pull}"
BRANCH="${BRANCH:-main}"

cd "$ROOT" || exit 1

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  echo "not a git repo — run 'git init -b $BRANCH' first, or see docs/playbooks/pc-migration.md" >&2
  exit 1
fi

have_remote() { git remote get-url origin >/dev/null 2>&1; }

case "$MODE" in
  pull)
    have_remote || { echo "no 'origin' remote configured" >&2; exit 1; }
    git pull --rebase origin "$BRANCH"
    echo "✓ pulled $BRANCH"
    ;;

  push)
    git add -A
    if git diff --cached --quiet; then
      echo "nothing to commit"
      exit 0
    fi
    git commit -m "chore: sync $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    have_remote && git push origin "$BRANCH"
    echo "✓ pushed $BRANCH"
    ;;

  cycle)
    have_remote && git pull --rebase origin "$BRANCH"
    bash scripts/paper-cycle.sh "$@"
    git add -A
    git diff --cached --quiet || {
      git commit -m "chore: paper cycle $(date -u +%Y-%m-%dT%H:%M:%SZ)"
      have_remote && git push origin "$BRANCH"
    }
    echo "✓ cycle done and synced"
    ;;

  *)
    echo "usage: bash scripts/sync.sh [pull|push|cycle]" >&2
    exit 2
    ;;
esac
