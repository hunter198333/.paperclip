#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# doctor.sh — check that this machine can actually run an agent-run trading desk.
#
#   bash scripts/doctor.sh
#
# Read-only. Fixes nothing, tells you exactly what to run.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export BUSINESS_ROOT="${BUSINESS_ROOT:-$ROOT}"
PASS=0; FAIL=0; WARN=0

ok()   { printf '  \033[32m✓\033[0m %-30s %s\n' "$1" "${2:-}"; PASS=$((PASS+1)); }
no()   { printf '  \033[31m✗\033[0m %-30s %s\n' "$1" "${2:-}"; FAIL=$((FAIL+1)); }
wa()   { printf '  \033[33m!\033[0m %-30s %s\n' "$1" "${2:-}"; WARN=$((WARN+1)); }
head_() { printf '\n\033[1m%s\033[0m\n' "$*"; }

echo "Trading desk doctor — $ROOT"

head_ "Toolchain"
if command -v node >/dev/null 2>&1; then
  NV=$(node -v | sed 's/^v//')
  MAJ=${NV%%.*}
  if [ "$MAJ" -ge 24 ] 2>/dev/null; then ok "node" "$NV"; else
    no "node" "$NV — Paperclip needs 24+. In Termux: pkg install nodejs-lts"; fi
else
  no "node" "not found. In Termux: pkg install nodejs-lts   (Acode's JS runtime does NOT count)"
fi

if command -v pnpm >/dev/null 2>&1; then ok "pnpm" "$(pnpm -v)"; else wa "pnpm" "not found — needed for the workspace root"; fi
if command -v git >/dev/null 2>&1; then
  ok "git" "$(git --version | cut -d' ' -f3)"
  if git config --global user.email >/dev/null 2>&1; then ok "git identity" "$(git config --global user.email)"; else
    wa "git identity" "unset — commits fail. Run: git config --global user.email you@example.com"; fi
else
  no "git" "not found — Paperclip needs git for worktrees"
fi
if command -v gh >/dev/null 2>&1; then ok "gh (GitHub CLI)" "$(gh --version 2>/dev/null | head -1)"; else
  wa "gh (GitHub CLI)" "not found — agents can't open PRs without it"; fi

head_ "Paperclip"
if command -v paperclipai >/dev/null 2>&1; then ok "paperclipai CLI" "$(command -v paperclipai)"; else
  if command -v npx >/dev/null 2>&1; then ok "npx" "will run: npx paperclipai"; else no "npx" "not found"; fi
fi

API_URL="${PAPERCLIP_API_URL:-http://127.0.0.1:3100}"
if [ -f "$ROOT/.paperclip/paperclip.env" ]; then
  set -a; . "$ROOT/.paperclip/paperclip.env"; set +a
  API_URL="${PAPERCLIP_API_URL:-$API_URL}"
fi
STATUS=$(node -e '
  const u=process.argv[1]; const c=new AbortController();
  setTimeout(()=>c.abort(),5000);
  fetch(u,{signal:c.signal}).then(r=>console.log(r.status)).catch(()=>console.log("unreachable"));
' "$API_URL" 2>/dev/null)
if [ "$STATUS" = "unreachable" ] || [ -z "$STATUS" ]; then
  wa "server at $API_URL" "not answering — start it with: npx paperclipai run"
else
  ok "server at $API_URL" "HTTP $STATUS"
fi

head_ "Agent adapter CLI"
ADAPTER=$(node -e 'const c=require(process.env.BUSINESS_ROOT+"/.paperclip/business.config.json");console.log(c.paperclip.adapterTypeDefault)')
case "$ADAPTER" in
  claude_local)   BIN=claude ;;
  codex_local)    BIN=codex ;;
  opencode_local) BIN=opencode ;;
  hermes_local)   BIN=hermes ;;
  *)              BIN="" ;;
esac
if [ -n "$BIN" ]; then
  if command -v "$BIN" >/dev/null 2>&1; then ok "$BIN ($ADAPTER)" "$(command -v "$BIN")"; else
    no "$BIN ($ADAPTER)" "not found — install it, or change adapterType in .paperclip/business.config.json"; fi
else
  wa "adapter" "unknown: $ADAPTER"
fi

head_ "Trading safety"
MODE_FILE="$ROOT/.paperclip/trading.mode"
if [ -f "$MODE_FILE" ]; then
  MODE=$(head -n 1 "$MODE_FILE" | tr -d '[:space:]')
  case "$MODE" in
    paper) ok "trading mode" "paper — safe default";;
    live)  wa "trading mode" "LIVE — real orders are possible";;
    *)     no "trading mode" "invalid value '$MODE' — run: bash scripts/trading-mode.sh paper";;
  esac
else
  no "trading mode" "missing .paperclip/trading.mode — run: bash scripts/trading-mode.sh paper"
fi

if [ -f "$ROOT/docs/trading/risk-policy.md" ]; then
  ok "risk policy" "docs/trading/risk-policy.md"
  DEFAULTS=$(awk -F'|' '/^\| L[0-9]+ / { v=$(NF-1); gsub(/^[[:space:]]+|[[:space:]]+$/, "", v); if (v=="") c++ } END { print c+0 }' "$ROOT/docs/trading/risk-policy.md")
  if [ "$DEFAULTS" -gt 0 ] 2>/dev/null; then
    wa "risk limits" "$DEFAULTS limit(s) still on conservative defaults — review before going live"
  else
    ok "risk limits" "all set by Max"
  fi
else
  no "risk policy" "missing docs/trading/risk-policy.md"
fi

LEAK=$(grep -rInE "(api[_-]?key|api[_-]?secret|secret[_-]?key|passphrase)[[:space:]]*[:=][[:space:]]*['\"][A-Za-z0-9_/+-]{16,}" \
      "$ROOT/workspaces" "$ROOT/docs" "$ROOT/scripts" 2>/dev/null | head -3)
if [ -n "$LEAK" ]; then
  no "hardcoded secrets" "$(printf '%s' "$LEAK" | head -1 | cut -c1-90)"
else
  ok "hardcoded secrets" "none in workspaces/docs/scripts"
fi

if grep -rInE "(BINANCE|BYBIT|COINBASE|KRAKEN|OKX)[A-Z_]*(KEY|SECRET)" "$ROOT/workspaces/research" 2>/dev/null | head -1 | grep -q .; then
  no "research workspace" "references an exchange key — it must have none"
else
  ok "research workspace" "no exchange key references"
fi

if [ -x "$ROOT/scripts/position-size.sh" ]; then ok "position sizer" "scripts/position-size.sh"; else
  no "position sizer" "missing scripts/position-size.sh"; fi

# Android shared storage needs git's file-mode check off, or every file looks modified
if printf '%s' "$ROOT" | grep -qE '/storage/(shared|emulated)'; then
  if [ "$(git config --global core.fileMode 2>/dev/null)" = "false" ]; then
    ok "shared storage git" "core.fileMode=false"
  else
    wa "shared storage git" "run: git config --global core.fileMode false"
  fi
fi

head_ "Workspaces"
for d in "$ROOT"/workspaces/*/; do
  [ -d "$d" ] || continue
  name=$(basename "$d")
  if [ -d "$d/.git" ]; then
    branch=$(git -C "$d" branch --show-current 2>/dev/null)
    if [ "$branch" = "main" ]; then ok "workspaces/$name" "git repo on main"; else
      wa "workspaces/$name" "git repo on '${branch:-?}' (Paperclip branches off 'main')"; fi
  else
    no "workspaces/$name" "not a git repo — run: bash scripts/git-init.sh"
  fi
done

head_ "Config"
if [ -f "$ROOT/.paperclip/paperclip.env" ]; then ok ".paperclip/paperclip.env" "present (git-ignored)"; else
  wa ".paperclip/paperclip.env" "missing — copy .paperclip/paperclip.env.example and fill it in"; fi
if [ -f "$ROOT/.paperclip/agent-ids.json" ]; then ok ".paperclip/agent-ids.json" "present"; else
  wa ".paperclip/agent-ids.json" "missing — run: bash .paperclip/bootstrap.sh"; fi

BRIEF="$ROOT/docs/business-brief.md"
if [ -f "$BRIEF" ]; then
  TODO=$(grep -c '\[TODO: Max\]' "$BRIEF" 2>/dev/null || echo 0)
  if [ "$TODO" -gt 0 ]; then
    wa "docs/business-brief.md" "$TODO question(s) waiting on Max"
  else
    ok "docs/business-brief.md" "complete"
  fi
else
  no "docs/business-brief.md" "missing"
fi

printf '\n\033[1m%d passed · %d warnings · %d failed\033[0m\n' "$PASS" "$WARN" "$FAIL"
[ "$FAIL" -gt 0 ] && exit 1
exit 0
