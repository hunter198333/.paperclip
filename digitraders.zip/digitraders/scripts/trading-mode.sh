#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# trading-mode.sh — the desk's on/off switch.
#
#   bash scripts/trading-mode.sh show      # what's the current mode?
#   bash scripts/trading-mode.sh paper     # back to paper (instant, safe)
#   bash scripts/trading-mode.sh live      # requires typing the confirm phrase
#
# The mode lives in .paperclip/trading.mode and is read by every agent before it
# proposes execution. Default is paper. Only the human flips it to live.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE_FILE="$ROOT/.paperclip/trading.mode"
CONFIRM="ENABLE LIVE TRADING"

mkdir -p "$(dirname "$MODE_FILE")"
[ -f "$MODE_FILE" ] || printf 'paper\n' > "$MODE_FILE"

current() { head -n 1 "$MODE_FILE" | tr -d '[:space:]'; }
set_mode() { printf '%s\n' "$1" > "$MODE_FILE"; }

case "${1:-show}" in
  show)
    M=$(current)
    echo "Trading mode: $M"
    if [ "$M" = "live" ]; then
      echo ""
      echo "  ╔══════════════════════════════════════════════════════╗"
      echo "  ║  LIVE MODE — real orders can be placed.               ║"
      echo "  ║  Every trade still needs a risk check AND approval.   ║"
      echo "  ╚══════════════════════════════════════════════════════╝"
    else
      echo "Paper mode — no real orders can be placed. This is the safe default."
    fi
    ;;

  paper)
    set_mode paper
    echo "✓ Trading mode set to PAPER."
    echo "  No live order can be placed. Paper trades still work normally."
    ;;

  live)
    echo ""
    echo "  ╔══════════════════════════════════════════════════════╗"
    echo "  ║  You are about to enable LIVE trading.                ║"
    echo "  ║                                                      ║"
    echo "  ║  Agents may place REAL orders once a trade has:       ║"
    echo "  ║   1. a written proposal in docs/trading/journal/      ║"
    echo "  ║   2. a RISK CHECK: PASS from Risk and Ops             ║"
    echo "  ║   3. your explicit approval on the issue              ║"
    echo "  ║                                                      ║"
    echo "  ║  Live mode alone does NOT authorise any trade.         ║"
    echo "  ╚══════════════════════════════════════════════════════╝"
    echo ""
    printf 'Type exactly "%s" to continue: ' "$CONFIRM"
    read -r ANSWER
    if [ "$ANSWER" != "$CONFIRM" ]; then
      echo "Confirmation did not match — staying in PAPER mode."
      exit 1
    fi
    set_mode live
    echo "✓ Trading mode set to LIVE."
    echo "  Reminder: paper-trading evidence first. See docs/trading/risk-policy.md"
    ;;

  *)
    echo "usage: bash scripts/trading-mode.sh [show|paper|live]" >&2
    exit 2
    ;;
esac
