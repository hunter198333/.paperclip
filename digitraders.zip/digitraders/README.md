# Digitraders

A local workspace for a **Paperclip** company of AI agents running a crypto trading desk
on **Kraken** — research, strategy code, backtests, position sizing, risk checks, and the
paper trail.

Built phone-first (Termux + Acode), because that's where it runs.

---

## 0. The safety model — read this first

This desk can touch real money. So the scaffold is built around one idea:

> **Paper by default. Four steps before anything real. One kill switch.**

| Mechanism | Where | What it does |
|---|---|---|
| **Mode file** | `.paperclip/trading.mode` | `paper` (default) or `live`. Every agent reads it before proposing execution. |
| **Risk policy** | `docs/trading/risk-policy.md` | The limits. Position size, daily loss, drawdown, leverage, fees. Only you edit it. |
| **Approval chain** | `docs/trading/trade-playbook.md` | thesis → proposal → risk check → **your approval** → execution. |
| **Sizer** | `scripts/position-size.sh` | Sizes a trade and checks it against the policy. Read-only. |
| **Journal** | `docs/trading/journal/` | Append-only record of every proposal and fill. |
| **Kill switch** | `risk-policy.md` §4 | Hit a limit → the desk stops. It doesn't try to win it back. |

```bash
bash scripts/trading-mode.sh show     # paper | live
bash scripts/trading-mode.sh paper    # back to safe (instant)
bash scripts/trading-mode.sh live     # needs you to type the confirm phrase
```

**Live mode alone doesn't authorise anything.** Even in live mode, no order happens
without thesis → proposal → risk check → your approval.

The **research workspace has no trading key by design.** The analyst can look, not touch.

---

## 1. The numbers that shape everything

**Kraken Tier 1 (30-day volume $0+): 0.40% maker / 0.80% taker.**

At ~$250 equity:

| | Maker (limit) | Taker (market) |
|---|---|---|
| Round-trip fee | 0.80% | 1.60% |
| Cost of a $250 round trip | **$2.00** | **$4.00** |
| Minimum gross edge to break even (policy L13) | **3.2%** | 6.4% |

Two consequences that are baked into the policy:

1. **Fees are the biggest cost line at this size.** Sizing discipline beats finding a
   better signal.
2. **Maker orders only** (policy L15). A market order doubles the drag for nothing.

And the honest one: with capital this size, **the rig and the learning are the
deliverable.** The P&L is the lab fee. That's not a failure — it's the cheapest possible
place to learn how to run an agent desk.

### Your capital plan

| | |
|---|---|
| Starting balance | **$250.00** |
| Weekly contribution | **+$100.00 per payday** |
| Projected balance by Christmas (≈7 deposits) | **~$950** |

**The account reaches ~$950 by Christmas because of deposits, not trading.** That's the
plan, and it's a good one — contributions compound without a single losing trade.

So the desk tracks three numbers, and never mixes them:

| Number | What it is |
|---|---|
| **Capital in the account** | $250 + every deposit. Not performance. |
| **Trading P&L** | What the desk actually made. **The only number that measures the desk.** |
| **Total equity** | Capital in + trading P&L. |

A growing account with flat trading P&L means the desk isn't working yet — and the
status page says so in those words.

---

## 2. Getting Node installed

Paperclip needs **Node.js 24+**. If you installed Node *inside Acode*, that doesn't count —
Acode has its own JS runtime, but Paperclip needs a real Node in your terminal.

**On the phone (Termux):**

```bash
pkg update && pkg upgrade
pkg install nodejs-lts      # → Node 24.x (Active LTS) — this is the one you want
node -v                     # must print v24.x or higher
```

`nodejs-lts` and `nodejs` conflict — **only one at a time.** If `node -v` shows v20/v22
you have the stale package: `pkg uninstall nodejs-lts && pkg install nodejs-lts`.

**On the PC:**

```bash
node -v                     # v24+ — if it's older: nvm install 24, or nodejs.org
npm i -g paperclipai       # permanent CLI
```

The engine, the paper cycle, and the agents all work the same either way.

---

## 3. Where it runs — phone or PC

**Both.** The installer picks the right location automatically: shared storage on
Android (so Acode can open it), your home directory everywhere else.

### On the phone (Acode)

Android apps can't read each other's private storage, so the installer puts Digitraders
in **shared storage**, where both Termux and Acode can see it:

```bash
termux-setup-storage      # once — tap ALLOW on the Android prompt
bash install.sh           # → /storage/emulated/0/digitraders
```

Then in Acode: **menu → Open folder → `/storage/emulated/0/digitraders`**

Termux reaches the same folder at `~/storage/shared/digitraders`.

> Shared storage doesn't preserve Unix permissions, so the installer turns off git's
> file-mode check and whitelists the directory. That's handled for you — you don't
> need to do anything.

### On the PC (recommended for running)

**One command does everything:**

```bash
bash pc-setup.sh
```

It checks Node 24, installs the Paperclip CLI, checks your git identity, installs a
timer so the paper cycle runs on its own every hour, registers the agents, runs the
first cycle, and prints a summary. It's safe to re-run — it never deletes anything
and never touches your keys.

```
bash pc-setup.sh --help        # all the flags
bash pc-setup.sh --yes         # no questions asked
bash pc-setup.sh --timer cron  # force a scheduler instead of auto-detect
```

The PC is the better place to *run* the desk:

| | Phone | PC |
|---|---|---|
| Paperclip's embedded Postgres | slow, sometimes won't boot | works |
| Long-running processes | Android kills them (signal 9) | fine, with a timer |
| **Kraken key IP allowlist** | impossible — mobile IP changes | **possible** |
| Long history, many agents | cramped | room to move |

Moving over? `docs/playbooks/pc-migration.md` — git (recommended, keeps them in sync)
or a zip over USB. `scripts/sync.sh pull|push|cycle` does the syncing for you.

---

## 4. What's in here

```
Digitraders/
├── AGENTS.md                  ← instruction layer every agent reads first
├── README.md                  ← you are here
├── package.json               ← pnpm workspace root
├── pnpm-workspace.yaml
│
├── .paperclip/
│   ├── business.config.json   ← company, goals, projects, workspaces, agents
│   ├── agents/*.json          ← per-agent cwd, timeouts, heartbeat, env
│   ├── trading.mode           ← "paper" | "live"  ← the switch
│   ├── bootstrap.sh           ← registers everything with Paperclip
│   ├── wake.sh                ← wake one agent, optionally on an issue
│   ├── status.sh              ← one-screen health of the desk
│   ├── paperclip.env.example  ← copy to paperclip.env and fill in
│   └── lib/                   ← tiny node helpers (no jq needed)
│
├── agents/
│   ├── desk/AGENTS.md         ← Desk Manager: priorities, proposals, assignment
│   ├── quant/AGENTS.md        ← Quant Developer: strategies, backtests, execution
│   ├── analyst/AGENTS.md      ← Market Analyst: research, signals, validation
│   └── risk/AGENTS.md         ← Risk and Ops: the veto, P&L, journal, kill switch
│
├── workspaces/
│   ├── engine/                ← strategy code + execution (the only one with keys)
│   │   ├── src/cli.js         ← backtest · walkforward · data · ticker
│   │   ├── src/engine/        ← simulator, metrics, indicators, walk-forward
│   │   ├── src/data/          ← Kraken public API + CSV import
│   │   ├── src/strategies/    ← buy-and-hold, sma-crossover, atr-breakout
│   │   └── tests/             ← 20 tests, incl. the no-lookahead proofs
│   ├── research/              ← market data, notes (read-only key at most)
│   └── ops/                   ← risk checks, dashboards, reports
│
├── deploy/
│   ├── systemd/                ← systemd unit + timer templates
│   └── launchd/                ← macOS launchd plist
│
├── docs/
│   ├── business-brief.md      ← FILL THIS IN FIRST (has [TODO: Max] markers)
│   ├── status-board.md        ← the daily dashboard
│   ├── trading/
│   │   ├── capital.md         ← every deposit, with dates (auto-generated)
│   │   ├── risk-policy.md     ← the limits — the law
│   │   ├── trade-playbook.md  ← the nine-step procedure
│   │   ├── paper-trading.md   ← the daily paper cycle
│   │   ├── paper-status.md    ← auto-generated paper account status
│   │   ├── experiments.md     ← every experiment, wins and failures
│   │   └── journal/           ← trade proposals + fills (append-only)
│   │       └── paper-ledger.md  ← every paper trade, auto-appended
│   ├── research/              ← analyst notes
│   ├── decisions/             ← why we did X
│   └── playbooks/
│       ├── kraken-setup.md    ← safe Kraken key creation
│       └── pc-migration.md    ← moving the desk to a PC
│
├── data/                      ← scratch, exports (git-ignored)
└── scripts/
    ├── doctor.sh              ← pre-flight check
    ├── git-init.sh            ← makes each workspace a git repo
    ├── position-size.sh       ← size a trade + check it against the policy
    ├── pc-setup.sh            ← ONE COMMAND: make this PC a running desk
    ├── paper-cycle.sh         ← run the paper-trading cycle
    ├── sync.sh                ← pull/push/cycle between phone and PC
    └── trading-mode.sh        ← the switch
```

---

## 5. Quick start

**On the PC — one command:**

```bash
unzip digitraders.zip
bash pc-setup.sh
```

**On the phone:**

```bash
# 1. Create the workspace
bash install.sh
cd ~/storage/shared/digitraders

# 2. Tell the desk what you're doing
nano docs/business-brief.md        # answer the [TODO: Max] questions

# 3. Make the workspaces git-ready (one worktree per issue, no collisions)
bash scripts/git-init.sh

# 4. Start Paperclip in ANOTHER terminal
npx paperclipai run                # first time: npx paperclipai onboard --yes
                                  # → board at http://127.0.0.1:3100

# 5. Register company + goals + projects + workspaces + agents
bash .paperclip/bootstrap.sh

# 6. Verify everything
bash scripts/doctor.sh
bash .paperclip/status.sh
```

Then: **stay in paper mode** and let the desk do research, backtests, and proposals.

---

## 6. The backtesting engine

`workspaces/engine/` is a **real, tested** backtester — no dependencies, pure Node,
nothing to install. It talks to Kraken's public API without a key.

```bash
cd workspaces/engine

# the benchmark — every strategy has to beat this, after fees
node src/cli.js backtest --strategy buy-and-hold --pair XRPUSD --interval 240

# a strategy
node src/cli.js backtest --strategy sma-crossover --pair XRPUSD --interval 240 --equity 250

# rolling out-of-sample test — trust only the stitched number
node src/cli.js walkforward --strategy sma-crossover --pair XRPUSD --interval 1440

# the tests
node --test tests/*.test.js
```

**The honesty is built in, not promised:**

- A signal on bar `i` fills at the **open of bar `i+1`** — never the close of bar `i`.
- Strategies **physically cannot read the future**; the engine throws if they try.
- Stops fill at the stop price, and if a bar contains both the stop and the target,
  **the stop wins**.
- Stop-outs are charged the **taker** fee, exits by target the maker fee.
- **No stop means no trade** — the engine refuses instead of guessing a size.
- Below 30 trades it prints **INSUFFICIENT SAMPLE** and exits `2`. That is a deliberate
  feature: it's the most common way people fool themselves.

First four runs are already logged in `docs/trading/experiments.md` — including the
ugly ones. Short version: the benchmark won, the SMA crossover lost to fees, and
walk-forward produced zero out-of-sample trades. That's the tool working.

### Writing your own strategy

```js
export function makeMyStrategy(params = {}) {
  return {
    name: 'my-strategy',
    params,
    onBar(ctx) {
      // ctx.bars is guarded — reading the future throws
      if (!ctx.position && myCondition(ctx)) {
        return { action: 'enter_long', stop: ctx.bar.close - 1.5 * atr, reason: 'why' };
      }
      return { action: 'hold' };
    },
  };
}
```

Register it in `src/strategies/index.js` with a **hypothesis** — the sentence you'd write
in the experiment log *before* you run it.

## 7. The paper-trading cycle

This is the rig's heartbeat. One command:

```bash
bash scripts/paper-cycle.sh              # one cycle
bash scripts/paper-cycle.sh --loop 60    # every hour
```

Each cycle pulls live candles from **Kraken's public API** (no key, no account access,
no orders), runs the strategy through the **same engine** that would place a real order,
logs closed paper trades to an append-only ledger, and rewrites the paper status file.

```
equity            $244.77         benchmark   $244.77
net p&l           -$5.23          net %       -2.09%
edge              +$15.70         vs buy&hold
trades            1               win rate    0.00%
profit factor     0.00            max DD      2.94%
fees              $0.71           exposure    99.51%
```

**The edge is the number that matters** — strategy versus doing nothing, same
constraints, same fees. Negative edge means stop.

Where it lands:

| File | Who writes it |
|---|---|
| `docs/trading/paper-status.md` | the cycle (auto, overwritten) |
| `docs/trading/journal/paper-ledger.md` | the cycle (auto, append-only) |
| `docs/status-board.md` | the Risk and Ops agent (the human-facing board) |

The agents take it from there: **Quant** runs the cycle, **Ops** summarises it on the
board, **Desk** refuses to propose a trade the paper account doesn't support.

It cannot place an order — there is no code path from the paper cycle to an exchange
write. That property is in the code, not in a promise.

---

## 8. The agents

Four agents, each with a job, each with its own instruction file.

| Agent | Shortname | Does | Heartbeat |
|---|---|---|---|
| Desk Manager | `desk` | Reviews the desk, prioritises, proposes trades | every 4h |
| Quant Developer | `quant` | Runs the paper cycle, logs experiments | hourly |
| Market Analyst | `analyst` | Research, signals, validation | off — wakes when assigned |
| Risk and Ops | `risk` | Risk checks, status board, kill switch | hourly |

```bash
bash .paperclip/wake.sh quant --reason "Run the paper cycle and log it"
bash .paperclip/status.sh               # company, agents, issues, runs
bash .paperclip/bootstrap.sh --update   # push changed agent configs
```

### The cost dial — read this one

**Every agent wakeup costs money.** A wakeup is an LLM run. The schedule above is a
starting point, not a recommendation:

- The **paper cycle itself is free** — it's a deterministic script. Run it from cron or
  systemd and it costs nothing. Only the agents' *interpretation* costs.
- If the bill gets uncomfortable, dial the intervals up in `.paperclip/agents/*.json`
  (they're in seconds) and re-run `bash .paperclip/bootstrap.sh --update`.
- The **Risk agent is the one not to turn off.** It's what keeps the kill switch honest.

---

## 9. How Paperclip maps onto this

| Paperclip | This repo |
|---|---|
| Company | Digitraders (`DGT-1`, `DGT-2`, …) |
| Goal | trade safely · prove the strategy · run the desk |
| Project | Trading Engine · Market Research · Risk and Operations |
| Project workspace | `workspaces/engine` · `research` · `ops` |
| Agent | Desk Manager · Quant Developer · Market Analyst · Risk and Ops |
| Issue | one outcome, one owner, one workspace |

Two rules that make or break it:

1. **`cwd` must be an absolute path on the machine running Paperclip.** The config uses
   the token `$BUSINESS_ROOT`; `bootstrap.sh` expands it before anything is sent.
2. **The `cwd` must be a git repo** for the `git_worktree` policy (one isolated worktree
   per issue, so parallel agents never collide). That's `scripts/git-init.sh`.

---

## 10. Day-to-day

```bash
bash scripts/pc-setup.sh                 # re-run the setup (safe, idempotent)
bash scripts/paper-cycle.sh              # run the paper-trading cycle
bash scripts/paper-cycle.sh --deposit 100 --note "payday"   # log a contribution
bash scripts/sync.sh cycle               # pull, run the cycle, commit, push
bash scripts/trading-mode.sh show        # am I in paper or live?
bash scripts/position-size.sh --equity 250 --entry 1.85 --stop 1.78 --edge 3.5
cd workspaces/engine && node src/cli.js backtest --strategy sma-crossover --interval 240
bash .paperclip/wake.sh quant --reason "Backtest the mean-reversion idea"
bash .paperclip/wake.sh risk  --reason "Daily risk check"
bash .paperclip/status.sh                # company, agents, issues, runs, workspaces
npx paperclipai run live                 # watch a run stream
```

**A normal day looks like:** the Analyst writes a thesis → the Quant Dev backtests it →
the Desk Manager writes a proposal → the Risk agent checks it → you read it and decide.
In paper mode, step 5 is the paper engine, and everything still gets logged.

---

## 11. Android / Termux gotchas

- **Paperclip holds the terminal.** It runs a Node server with an embedded Postgres.
  Keep it in its own terminal session or nothing reaches it.
- **Embedded Postgres on Android can be slow or fail to boot.** If `npx paperclipai run`
  dies on the database, run Paperclip on a cheap VPS instead and point the phone at it:
  `export PAPERCLIP_API_URL=https://your-host:3100` (the CLI also takes `--api-base`).
  The agents then run wherever Paperclip runs — the `cwd` has to exist there too.
  **This is also the answer to the Kraken IP-allowlist problem:** a phone on mobile data
  has no stable IP, so a fixed execution host is what makes a locked-down key possible.
- **Android 12+ kills background processes** with signal 9. Don't let Paperclip run in
  the background; give it a foreground terminal.
- **arm64 native modules sometimes fail to build.** `pkg install python build-essential`
  if a package needs to compile.
- **Keep the API on loopback.** Don't expose Paperclip publicly without reading the
  deployment docs.
- **`npx paperclipai` always works;** `npx paperclipai install` puts a permanent
  `paperclipai` command in `~/.local/bin`.

---

## 12. Make it yours

| What | Where |
|---|---|
| Capital, strategy, your numbers | `docs/business-brief.md` (the `[TODO: Max]` lines) |
| Company name, issue prefix, goals, projects | `.paperclip/business.config.json` |
| Risk limits and fees | `docs/trading/risk-policy.md` §1 |
| Which agent CLI runs | `business.config.json` → `paperclip.adapterTypeDefault` |
| Where the desk lives | `BUSINESS_ROOT` env var in `install.sh` |

`adapterType` is `codex_local` by default. Claude Code → `claude_local`;
OpenCode → `opencode_local`. One line, then re-run `bootstrap.sh`.

---

## 13. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `node: command not found` | Node isn't in the terminal (Acode's runtime doesn't count) | `pkg install nodejs-lts` |
| `node -v` shows v20/v22 | old `nodejs-lts` package | `pkg uninstall nodejs-lts && pkg install nodejs-lts` |
| Acode can't see the folder | storage permission not granted | `termux-setup-storage`, then re-run `install.sh` |
| `paperclipai: command not found` | CLI not installed / not on PATH | `npx paperclipai install`, reopen the terminal |
| `EADDRINUSE :3100` | Paperclip already running | `npx paperclipai run` from the other terminal |
| Postgres won't start | embedded DB on Android | move Paperclip to a VPS, set `PAPERCLIP_API_URL` |
| Worktree creation fails | workspace isn't a git repo | `bash scripts/git-init.sh` |
| Agent can't push | no git identity / no remote | `git config --global user.email you@example.com` |
| Key leaked into a log | something printed a secret | revoke the key first, then debug |
| "RISK CHECK: FAIL" | a limit was hit | read the policy, don't work around it |

---

## 14. What's deliberately *not* here

- **No strategy of yours.** The engine ships with three baselines
  (`buy-and-hold`, `sma-crossover`, `atr-breakout`) so you have something to beat and
  something to copy. The edge is still yours to find — and the first four logged
  experiments say the baselines don't have one.
- **No live execution wiring.** It arrives after you've paper-traded something that
  actually works.
- **No exchange keys.** See `docs/playbooks/kraken-setup.md` when you're ready.

That's the point of `paper` mode: the rig can be built, tested, and broken safely while
the edge is still being figured out.
