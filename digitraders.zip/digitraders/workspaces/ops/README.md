# Risk and Operations

Risk policy enforcement, P&L, the trade journal, and the daily dashboard.

**Owner agent:** Risk and Ops
**Paperclip project:** Risk and Operations

## What's here

- `dashboards/` — the P&L / drawdown / exposure dashboard
- `reports/` — daily and weekly reports
- `checks/` — automated risk checks (position size, daily loss, drawdown)

## Rules

- **Read-only on money.** This workspace prepares reports and checks limits. It never
  places, modifies, or closes an order.
- **The risk policy is the source of truth** — `docs/trading/risk-policy.md`. If a check
  disagrees with the policy, the policy wins and the check is a bug.
- **Never edit the trade journal.** Corrections are appended.
- Raw exchange exports belong in `data/` (git-ignored), not here.

## Layout

```
workspaces/ops/
├── dashboards/   # equity, drawdown, exposure
├── reports/      # daily / weekly
└── checks/       # automated limit checks
```
