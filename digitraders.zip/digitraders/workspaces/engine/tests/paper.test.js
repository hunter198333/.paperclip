import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Point the paper module at a temp dir BEFORE it is imported.
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'paper-'));
process.env.DIGITRADERS_PAPER_STATE_DIR = path.join(tmp, 'state');
process.env.DIGITRADERS_PAPER_LEDGER = path.join(tmp, 'ledger.md');
process.env.DIGITRADERS_PAPER_STATUS = path.join(tmp, 'status.md');

const { runPaperCycle } = await import('../src/paper/runner.js');
const { loadState, appendToLedger, resetPaper, LEDGER_FILE, STATE_FILE } = await import('../src/paper/portfolio.js');

/** Deterministic candles: a clean uptrend so a long actually makes money. */
function makeBars(n = 200, start = 100) {
  return Array.from({ length: n }, (_, i) => {
    const price = start + i * 0.5;
    return {
      time: Date.UTC(2026, 0, 1) + i * 3600 * 1000,
      open: price,
      high: price + 0.3,
      low: price - 0.3,
      close: price + 0.15,
      volume: 1000,
    };
  });
}

test('a paper cycle produces a record, a ledger row and a status file', async () => {
  const bars = makeBars();
  const status = await runPaperCycle({
    strategy: 'buy-and-hold',
    pair: 'TESTUSD',
    interval: 60,
    equity: 250,
    reset: true,
    paperStart: new Date(bars[10].time).toISOString(),
    bars,
  });

  assert.ok(status.paperTrades.length >= 1, 'expected at least one paper trade');
  assert.ok(fs.existsSync(STATE_FILE), 'state file written');
  assert.ok(fs.existsSync(LEDGER_FILE), 'ledger written');
  assert.ok(fs.existsSync(path.join(tmp, 'status.md')), 'status file written');

  const ledger = fs.readFileSync(LEDGER_FILE, 'utf8');
  assert.match(ledger, /\| Closed \(UTC\)/);
  assert.ok(ledger.split('\n').filter((l) => l.startsWith('| 2026')).length >= 1);
});

test('running the cycle again does not duplicate ledger rows', async () => {
  const bars = makeBars();
  await runPaperCycle({
    strategy: 'buy-and-hold', pair: 'TESTUSD', interval: 60, equity: 250,
    paperStart: new Date(bars[10].time).toISOString(), bars,
  });
  const before = fs.readFileSync(LEDGER_FILE, 'utf8').split('\n').filter((l) => l.startsWith('| 2026')).length;
  await runPaperCycle({
    strategy: 'buy-and-hold', pair: 'TESTUSD', interval: 60, equity: 250,
    paperStart: new Date(bars[10].time).toISOString(), bars,
  });
  const after = fs.readFileSync(LEDGER_FILE, 'utf8').split('\n').filter((l) => l.startsWith('| 2026')).length;
  assert.equal(after, before, 'the same paper trade must not be logged twice');
});

test('the paper record starts fresh — no trades before paperStart', async () => {
  const bars = makeBars();
  const status = await runPaperCycle({
    strategy: 'buy-and-hold', pair: 'TESTUSD', interval: 60, equity: 250,
    reset: true,
    paperStart: new Date(bars[150].time).toISOString(),
    bars,
  });
  for (const t of status.paperTrades) {
    assert.ok(t.entryTime >= bars[150].time, 'no trade may predate the paper start');
  }
});

test('the benchmark is held to the same notional cap as the strategy', async () => {
  const bars = makeBars();
  const status = await runPaperCycle({
    strategy: 'sma-crossover', pair: 'TESTUSD', interval: 60, equity: 250,
    reset: true,
    paperStart: new Date(bars[10].time).toISOString(),
    bars,
  });
  // Same constraints on both sides means the edge is a like-for-like comparison
  assert.ok(Number.isFinite(status.edge));
});

test('reset clears both the state and the ledger', async () => {
  const bars = makeBars();
  await runPaperCycle({
    strategy: 'buy-and-hold', pair: 'TESTUSD', interval: 60, equity: 250,
    reset: true, paperStart: new Date(bars[10].time).toISOString(), bars,
  });
  assert.ok(fs.readFileSync(LEDGER_FILE, 'utf8').split('\n').some((l) => l.startsWith('| 2026')));

  resetPaper();
  const rows = fs.readFileSync(LEDGER_FILE, 'utf8').split('\n').filter((l) => l.startsWith('| 2026'));
  assert.equal(rows.length, 0, 'reset must clear the ledger too');
  assert.equal(loadState(), null, 'reset must clear the state');
});

test('the ledger keeps its header after a reset', () => {
  const content = fs.readFileSync(LEDGER_FILE, 'utf8');
  assert.match(content, /# Paper Trade Ledger/);
  assert.match(content, /\| Closed \(UTC\)/);
});
