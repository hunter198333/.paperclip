import test from 'node:test';
import assert from 'node:assert/strict';
import { backtest } from '../src/engine/backtest.js';
import { computeMetrics } from '../src/engine/metrics.js';

function bar(time, open, high, low, close) {
  return { time, open, high, low, close, volume: 100 };
}

function series(n, fn) {
  return Array.from({ length: n }, (_, i) => fn(i));
}

/**
 * Deposits are money going IN. They must never look like profit.
 */
test('a deposit increases the cash but is not counted as trading profit', () => {
  const bars = series(6, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'flat',
    onBar: () => ({ action: 'hold' }),
  }, { initialEquity: 250, deposits: [{ barIndex: 2, amount: 100 }], makerFee: 0, takerFee: 0 });

  assert.equal(result.totalDeposits, 100);
  assert.equal(result.finalEquity, 350, 'the account holds the deposit');
});

test('a deposit re-sizes later positions', () => {
  const bars = series(9, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'sizer',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95 };  // opens at bar 1
      if (ctx.index === 2) return { action: 'exit' };                 // closes at bar 3
      if (ctx.index === 3) return { action: 'enter_long', stop: 95 };  // opens at bar 4
      return { action: 'hold' };
    },
  }, {
    initialEquity: 250,
    riskPct: 1,
    deposits: [{ barIndex: 2, amount: 250 }],
    makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100,
  });

  assert.equal(result.trades.length, 2, 'expected two round trips');

  // First trade: risk $2.50 (1% of 250) / $5 stop distance = 0.5 units
  assert.equal(result.trades[0].size, 0.5);

  // Second trade: the deposit landed on bar 2, so capital is $500 and
  // 1% risk = $5.00 / $5 = 1.0 units
  assert.equal(result.trades[1].size, 1);
});

test('metrics separate capital in from trading P&L', () => {
  const bars = series(6, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'flat',
    onBar: () => ({ action: 'hold' }),
  }, { initialEquity: 250, deposits: [{ barIndex: 1, amount: 100 }], makerFee: 0, takerFee: 0 });

  const m = computeMetrics(result, { minTrades: 30 });

  assert.equal(m.totalDeposits, 100);
  assert.equal(m.capitalBase, 350, 'capital in = starting + deposits');
  assert.equal(m.netProfit, 0, 'a deposit is not profit');
  assert.equal(m.finalEquity, 350, 'equity includes the deposit');
  assert.equal(m.netProfitPct, 0, 'return on capital is measured on capital in');
});

test('a deposit does not distort the profit factor or the trade list', () => {
  const bars = [
    bar(0, 100, 100, 100, 100),
    bar(1, 100, 100, 100, 100),
    bar(2, 100, 120, 100, 120),
    bar(3, 120, 120, 120, 120),
  ];

  const result = backtest(bars, {
    name: 'winner',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95, target: 120 };
      return { action: 'hold' };
    },
  }, {
    initialEquity: 250, riskPct: 10,
    deposits: [{ barIndex: 1, amount: 100 }],
    makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100,
  });

  const m = computeMetrics(result, { minTrades: 30 });
  assert.equal(m.totalTrades, 1);

  // The deposit landed before the fill, so the position is sized off $350:
  // risk $35 / $5 = 7 units, capped by the 100%-of-equity notional rule at $350
  // → 3.5 units. Entry 350, exit 3.5 × 120 = 420, so the trade made 70.
  assert.equal(m.netProfit, 70, 'only the trade P&L counts — not the deposit');
  assert.equal(m.totalDeposits, 100, 'the deposit is tracked separately');
  assert.equal(m.capitalBase, 350, 'capital in = starting + deposits');
  assert.equal(m.finalEquity, 420, 'equity = capital in + trading P&L');
});

test('a deposit made after the last candle still lands in the account', async () => {
  // Regression: a deposit dated now, when the newest candle is older, used to
  // be dropped entirely — the account silently ignored real money.
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dep-'));
  process.env.DIGITRADERS_PAPER_STATE_DIR = path.join(tmp, 'state');
  process.env.DIGITRADERS_PAPER_LEDGER = path.join(tmp, 'ledger.md');
  process.env.DIGITRADERS_PAPER_STATUS = path.join(tmp, 'status.md');

  const { runPaperCycle: run } = await import('../src/paper/runner.js');

  const bars = series(30, (i) => bar(Date.UTC(2026, 0, 1) + i * 3600 * 1000, 100, 100, 100, 100));

  const status = await run({
    strategy: 'buy-and-hold', pair: 'TESTUSD', interval: 60, equity: 250,
    reset: true,
    paperStart: new Date(bars[0].time).toISOString(),
    deposit: 100,
    depositNote: 'payday',
    bars,
  });

  assert.equal(status.totalDeposited, 100, 'the deposit must not be dropped');
  assert.equal(status.capitalBase, 350, 'capital in = starting + deposit');

  // The benchmark traded, so fees moved the equity a little — but the deposit
  // is in the account and it is NOT counted as profit.
  assert.ok(
    Math.abs(status.equity - 350) < 5,
    `equity should be ~350 minus fees, got ${status.equity}`,
  );
  assert.ok(
    status.metrics.netProfit < 0 && status.metrics.netProfit > -5,
    `trading P&L should be fees only (negative, small), got ${status.metrics.netProfit}`,
  );
});
