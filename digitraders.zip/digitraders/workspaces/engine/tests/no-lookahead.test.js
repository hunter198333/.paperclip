import test from 'node:test';
import assert from 'node:assert/strict';
import { backtest, createBarGuard } from '../src/engine/backtest.js';

/**
 * The most important tests in this repo.
 *
 * If the simulator leaks the future, every backtest lies, and the whole desk
 * is built on sand. These tests pin that down.
 */

function bar(time, open, high, low, close, volume = 100) {
  return { time, open, high, low, close, volume };
}

function series(n, fn) {
  return Array.from({ length: n }, (_, i) => fn(i));
}

test('a signal on bar i fills at the OPEN of bar i+1, never bar i', () => {
  const bars = series(6, (i) => bar(i * 1000, 100 + i, 101 + i, 99 + i, 100 + i));

  const result = backtest(bars, {
    name: 'enter-once',
    onBar(ctx) {
      if (ctx.index === 0) {
        return { action: 'enter_long', stop: 50, reason: 'test' };
      }
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100 });

  assert.equal(result.trades.length, 1);
  // bar 1 opens at 101 — the fill must be 101, not bar 0's close of 100
  assert.equal(result.trades[0].entryPrice, 101);
  assert.equal(result.trades[0].entryIndex, 1);
});

test('the strategy cannot read a future bar', () => {
  const bars = series(5, (i) => bar(i * 1000, 100, 101, 99, 100));

  const guarded = createBarGuard(bars, 2);
  assert.equal(guarded.length, 3);
  assert.equal(guarded[2].close, 100);
  assert.throws(() => guarded[3], /lookahead blocked/);
  assert.throws(() => guarded[4], /lookahead blocked/);
});

test('a strategy that tries to peek fails loudly instead of silently profiting', () => {
  const bars = series(10, (i) => bar(i * 1000, 100, 101, 99, 100));

  assert.throws(
    () =>
      backtest(bars, {
        name: 'cheater',
        onBar(ctx) {
          const future = ctx.bars[ctx.index + 1]; // peek
          return { action: 'hold', reason: String(future) };
        },
      }),
    /lookahead blocked/,
  );
});

test('a stop loss exits at the stop price and charges the taker fee', () => {
  // bar 1 opens at 100; bar 2 dives to 90 and the stop is at 95
  const bars = [
    bar(0, 100, 100, 100, 100),
    bar(1, 100, 100, 100, 100),
    bar(2, 100, 100, 90, 95),
    bar(3, 95, 95, 94, 94),
  ];

  const result = backtest(bars, {
    name: 'enter-once',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95 };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100, riskPct: 10 });

  assert.equal(result.trades.length, 1);
  assert.equal(result.trades[0].exitReason, 'stop');
  assert.equal(result.trades[0].exitPrice, 95);
});

test('when a bar contains both the stop and the target, the stop is assumed first', () => {
  // deliberately ambiguous bar — the engine must take the conservative path
  const bars = [
    bar(0, 100, 100, 100, 100),
    bar(1, 100, 100, 100, 100),
    bar(2, 100, 120, 80, 110), // hits both 95 and 120
    bar(3, 110, 110, 109, 109),
  ];

  const result = backtest(bars, {
    name: 'ambiguous',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95, target: 120 };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100, riskPct: 10 });

  assert.equal(result.trades[0].exitReason, 'stop');
  assert.ok(result.trades[0].pnl < 0, 'the ambiguous bar must not be a profit');
});

test('position sizing uses the risk percentage and the stop distance', () => {
  const bars = series(6, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'sizer',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95 };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, riskPct: 1, makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100 });

  // risk $10 / $5 distance = 2 units
  assert.equal(result.trades[0].size, 2);
  assert.equal(result.trades[0].notional, 200);
});

test('a trade with no stop and no size is rejected, not guessed', () => {
  const bars = series(6, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'no-stop',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long' };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, makerFee: 0, takerFee: 0, slippageBps: 0 });

  assert.equal(result.trades.length, 0);
  assert.match(result.logs.join('\n'), /no stop and no size/);
});

test('the max-notional cap shrinks an oversized position', () => {
  const bars = series(6, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'capped',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95 };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, riskPct: 50, makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 25 });

  assert.ok(result.trades[0].notional <= 250.0001, 'notional must respect the cap');
});

test('fees are charged on entry and on exit', () => {
  const bars = [
    bar(0, 100, 100, 100, 100),
    bar(1, 100, 100, 100, 100),
    bar(2, 100, 120, 100, 120),
    bar(3, 120, 120, 120, 120),
  ];

  const result = backtest(bars, {
    name: 'fees',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 95, target: 120 };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, makerFee: 0.004, takerFee: 0.008, slippageBps: 0, maxNotionalPct: 100, riskPct: 10 });

  assert.ok(result.totalFees > 0);
  assert.equal(result.trades[0].exitReason, 'target');

  // a target exit is a resting limit → maker fee on both legs
  const t = result.trades[0];
  const expected = t.notional * 0.004 + t.size * t.exitPrice * 0.004;
  assert.ok(
    Math.abs(result.totalFees - expected) < 0.001,
    `expected ${expected} in fees, got ${result.totalFees}`,
  );
});

test('an open position is closed at the end of the data', () => {
  const bars = series(5, (i) => bar(i * 1000, 100, 100, 100, 100));

  const result = backtest(bars, {
    name: 'still-open',
    onBar(ctx) {
      if (ctx.index === 0) return { action: 'enter_long', stop: 1 };
      return { action: 'hold' };
    },
  }, { initialEquity: 1000, makerFee: 0, takerFee: 0, slippageBps: 0, maxNotionalPct: 100, riskPct: 1 });

  assert.equal(result.trades.length, 1);
  assert.equal(result.trades[0].exitReason, 'end_of_data');
});
