import test from 'node:test';
import assert from 'node:assert/strict';
import { computeMetrics } from '../src/engine/metrics.js';

function trade(pnl, r = null, fee = 0, barsHeld = 10) {
  return { pnl, rMultiple: r, fees: fee, barsHeld, side: 'long' };
}

function curve(values) {
  return values.map((equity, i) => ({ time: i * 1000, equity, inPosition: false, cash: equity }));
}

test('profit factor, win rate and expectancy are computed from the trade list', () => {
  const trades = [trade(100, 1), trade(100, 1), trade(-50, -0.5), trade(-50, -0.5)];
  const m = computeMetrics({ trades, equityCurve: curve([1000, 1000, 1050, 1050]), initialEquity: 1000, totalFees: 10 });

  assert.equal(m.totalTrades, 4);
  assert.equal(m.wins, 2);
  assert.equal(m.losses, 2);
  assert.equal(m.winRate, 50);
  assert.equal(m.grossProfit, 200);
  assert.equal(m.grossLoss, 100);
  assert.equal(m.profitFactor, 2);
  assert.equal(m.netProfit, 100);
  assert.equal(m.netProfitPct, 10);
  assert.equal(m.expectancy, 25);
});

test('max drawdown is measured from the equity peak', () => {
  const m = computeMetrics({
    trades: [],
    equityCurve: curve([1000, 1200, 900, 1100]),
    initialEquity: 1000,
    totalFees: 0,
  });
  assert.equal(m.maxDrawdown, 300);
  assert.equal(Math.round(m.maxDrawdownPct), 25);
});

test('a sample below the minimum is reported as no conclusion', () => {
  const m = computeMetrics({
    trades: [trade(10), trade(5)],
    equityCurve: curve([1000, 1000, 1015]),
    initialEquity: 1000,
    totalFees: 0,
  }, { minTrades: 30 });
  assert.match(m.verdict, /INSUFFICIENT SAMPLE/);
});

test('fees are reported as a share of equity and of profit', () => {
  const m = computeMetrics({
    trades: [trade(100, 1, 10), trade(-20, -0.2, 5)],
    equityCurve: curve([1000, 1000, 1080]),
    initialEquity: 1000,
    totalFees: 15,
  });
  assert.equal(m.totalFees, 15);
  assert.equal(m.feesPctOfEquity, 1.5);
  assert.equal(m.feesVsProfit, 0.1875);
});

test('profit factor is infinite when there are no losers', () => {
  const m = computeMetrics({
    trades: [trade(50), trade(50)],
    equityCurve: curve([1000, 1100]),
    initialEquity: 1000,
    totalFees: 0,
  });
  assert.equal(m.profitFactor, Infinity);
});
