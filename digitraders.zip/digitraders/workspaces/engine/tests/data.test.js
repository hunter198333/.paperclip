import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { loadCsv, saveCsv } from '../src/data/csv.js';
import { krakenResultKey } from '../src/data/kraken.js';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'dt-'));

test('CSV with unix timestamps is parsed and sorted', () => {
  const dir = tmp();
  const file = path.join(dir, 'ohlc.csv');
  fs.writeFileSync(file, [
    'timestamp,open,high,low,close,volume',
    '1700007200,2.0,2.5,1.9,2.4,100',
    '1700003600,1.5,1.8,1.4,1.7,80',
    '1700005400,1.7,2.1,1.6,2.0,90',
  ].join('\n'));

  const bars = loadCsv(file);
  assert.equal(bars.length, 3);
  assert.equal(bars[0].close, 1.7);       // earliest first
  assert.equal(bars[2].close, 2.4);
  assert.equal(bars[0].time, 1700003600 * 1000);
  assert.equal(bars[0].volume, 80);
});

test('CSV with ISO dates and alternative headers works', () => {
  const dir = tmp();
  const file = path.join(dir, 'ohlc.csv');
  fs.writeFileSync(file, [
    'Date,Open,High,Low,Close,Vol',
    '2026-01-02,1.0,1.2,0.9,1.1,10',
    '2026-01-01,0.9,1.1,0.8,1.0,12',
  ].join('\n'));

  const bars = loadCsv(file);
  assert.equal(bars.length, 2);
  assert.equal(bars[0].open, 0.9);
  assert.equal(bars[1].close, 1.1);
  assert.equal(bars[0].time, Date.parse('2026-01-01'));
});

test('a CSV missing a required column fails with a helpful message', () => {
  const dir = tmp();
  const file = path.join(dir, 'bad.csv');
  fs.writeFileSync(file, 'time,open,close\n1700003600,1,2\n');
  assert.throws(() => loadCsv(file), /missing a "high" column/);
});

test('bars round-trip through save and load', () => {
  const dir = tmp();
  const file = path.join(dir, 'rt.csv');
  const bars = [
    { time: 1700003600000, open: 1, high: 2, low: 0.5, close: 1.5, volume: 10 },
    { time: 1700007200000, open: 1.5, high: 2.5, low: 1.2, close: 2.2, volume: 12 },
  ];
  saveCsv(file, bars);
  const back = loadCsv(file);
  assert.equal(back.length, 2);
  assert.equal(back[0].time, bars[0].time);
  assert.equal(back[1].close, 2.2);
});

test('Kraken legacy result keys are mapped', () => {
  assert.equal(krakenResultKey('XRPUSD'), 'XXRPZUSD');
  assert.equal(krakenResultKey('XBTUSD'), 'XXBTZUSD');
  assert.equal(krakenResultKey('ETHUSD'), 'XETHZUSD');
});
