# Trading Engine

The backtesting engine. **No dependencies** — pure Node, nothing to install, runs on the
phone straight from Acode or the terminal.

```
workspaces/engine/
├── src/
│   ├── cli.js              # backtest | walkforward | data | ticker | strategies
│   ├── config/defaults.js  # Kraken Tier-1 fees and every default in one place
│   ├── data/
│   │   ├── kraken.js       # public OHLC / ticker / order book (no key needed)
│   │   ├── csv.js          # import history from a CSV
│   │   └── store.js        # local cache
│   ├── engine/
│   │   ├── backtest.js     # the simulator
│   │   ├── metrics.js      # profit factor, drawdown, fees, verdict
│   │   ├── indicators.js   # SMA / EMA / ATR / RSI + incremental versions
│   │   └── walkforward.js  # rolling in-sample → out-of-sample
│   └── strategies/         # buy-and-hold, sma-crossover, atr-breakout
└── tests/                  # 20 tests, including the no-lookahead proofs
```

---

## The one rule that makes it honest

> **A signal is computed on the CLOSE of bar `i`. The fill happens at the OPEN of bar
> `i + 1`. Never the close of bar `i`, never the open of bar `i`.**

And it's not a promise — it's enforced. `ctx.bars` is a guarded view: if a strategy
reaches for a future bar, the engine **throws**:

```
lookahead blocked: strategy tried to read bar 412 while standing on bar 400
```

There's a test for it (`tests/no-lookahead.test.js`). If the simulator ever leaks the
future, every backtest lies, and the whole desk is built on sand.

Other things the simulator gets right so you don't have to think about them:

- **Stops fill at the stop price** (or worse, if the bar gapped through it).
- **If a bar contains both the stop and the target, the stop wins.** Always assume the
  worse one.
- **A stop-loss exit is a market order** → taker fee. A target exit can rest → maker fee.
- **Slippage is against you**, on every fill.
- **No stop means no trade.** Without a stop there's no honest way to size a position,
  so the engine refuses instead of guessing.
- **Position size is risk-based**: `size = (equity × risk%) ÷ |entry − stop|`, capped by
  the max-notional rule (policy L6).

---

## Usage

```bash
cd workspaces/engine

# what's in the cache
node src/cli.js data --pair XRPUSD --interval 240

# the benchmark — everything else has to beat this
node src/cli.js backtest --strategy buy-and-hold --pair XRPUSD --interval 240

# a strategy
node src/cli.js backtest --strategy sma-crossover --pair XRPUSD --interval 240 --equity 250

# with a stricter read
node src/cli.js backtest --strategy sma-crossover --pair XRPUSD --interval 240 --edge 3.5

# rolling out-of-sample test — trust only the stitched number
node src/cli.js walkforward --strategy sma-crossover --pair XRPUSD --interval 1440

# deep history from a CSV
node src/cli.js backtest --strategy sma-crossover --csv ~/ohlc/XRPUSD_240.csv

# list strategies and their hypotheses
node src/cli.js strategies
```

With pnpm (from the business root):

```bash
pnpm --filter @trading/engine run backtest -- --strategy sma-crossover --interval 240
```

### Useful flags

| Flag | Default | Meaning |
|---|---|---|
| `--equity` | 250 | starting account equity |
| `--risk` | 0.5 | risk per trade, % of equity (policy L1) |
| `--maker-fee` | 0.004 | Kraken Tier 1 maker |
| `--taker-fee` | 0.008 | Kraken Tier 1 taker |
| `--slippage` | 5 | basis points against you |
| `--max-notional` | 25 | max position as % of equity (policy L6) |
| `--min-trades` | 30 | below this, the exit code is 2 and the verdict says "no conclusion" |
| `--force` | — | ignore the sample-size verdict |
| `--out` | — | write full results as JSON |

---

## Data

Kraken's public OHLC needs **no key** and returns up to 720 candles:

| Interval | History you get |
|---|---|
| 240 (4h) | ~30 days |
| 1440 (1d) | ~2 years |
| 60 (1h) | ~30 days |

For deeper history, download a CSV and use `--csv`:

- **CryptoDataDownload** (free): <https://www.cryptodatadownload.com/data/kraken/>
- **KrakenData** (paid): <https://www.kraken.com/data>

The CSV parser is forgiving — it sniffs the header, accepts Unix or ISO timestamps, and
sorts by time. Columns needed: `time, open, high, low, close, volume`.

> Watch the venue. Data from another exchange is fine for **research**, but fills,
> spreads, and depth are venue-specific. A backtest on Binance data tells you about
> Binance, not Kraken.

---

## Writing a strategy

A strategy is an object with an `onBar(ctx)` method:

```js
export function makeMyStrategy(params = {}) {
  const p = { ...params };
  const atr = new RollingAtr(14);

  return {
    name: 'my-strategy',
    params: p,
    onBar(ctx) {
      const a = atr.push(ctx.bar);
      if (!a) return { action: 'hold' };

      if (ctx.position && ctx.bar.close < ctx.position.entryPrice * 0.98) {
        return { action: 'exit', reason: 'closed below -2%' };
      }

      if (!ctx.position && someCondition(ctx)) {
        return {
          action: 'enter_long',
          stop: ctx.bar.close - 1.5 * a,   // REQUIRED — no stop, no trade
          target: ctx.bar.close + 3 * a,  // optional
          reason: 'why you think this works',
        };
      }
      return { action: 'hold' };
    },
  };
}
```

**`ctx` gives you:** `bars` (guarded — no future), `index`, `bar`, `position`,
`equity`, `cash`, `params`, `log()`.

**Signals:** `{ action: 'enter_long' | 'enter_short' | 'exit' | 'hold', stop?, target?,
size?, notionalPct?, reason? }`

**Rules:**
- A `stop` is mandatory for risk-sized entries.
- `reason` is not optional in practice — it goes into the trade journal.
- Never read `ctx.bars` beyond `ctx.index`. The engine will stop you, but it's noise.

Register it in `src/strategies/index.js` with a **hypothesis** — the sentence you'd write
in the experiment log *before* you run it.

---

## Writing a good hypothesis

The engine will happily backtest a bad idea all day. Your job is to make sure it's
worth running. A hypothesis should name:

1. **What you believe** — a claim about the market, not about an indicator.
2. **Why it might be true** — a mechanism, not a pattern.
3. **What would make you wrong** — the invalidation.

> ✅ *"Funding rates on perp markets lead spot by ~1 hour, so extreme positive funding
> predicts a 2% pullback within 8 candles."*
> ❌ *"RSI looks oversold at the bottom."*

Then log it in `docs/trading/experiments.md` **before** you run it.

---

## Tests

```bash
node --test tests/*.test.js
```

20 tests. The important ones are in `tests/no-lookahead.test.js` — they prove the
simulator can't be fooled by a future-peeking strategy, that ambiguous bars resolve
conservatively, and that sizing and fees behave.

Run them before you trust any number this engine produces.

---

## What this engine does NOT do

- **No live trading.** That's `src/execution/`, and it doesn't exist yet — by design.
  See `docs/trading/trade-playbook.md` for what has to happen first.
- **No order book simulation.** It models fills at bar prices plus slippage, not
  walking a book. Good enough for strategy research, not for sizing a $50k order.
- **No intrabar data.** It uses OHLC, not ticks.
- **No optimisation framework.** Parameter sweeps are a trap (they fit noise). Do them
  by hand, one variable at a time, and log every attempt.
