import { withDefaults } from '../config/defaults.js';

/**
 * The simulator.
 *
 * ── The one rule that makes a backtest honest ──────────────────────────────────
 * A signal is computed on the CLOSE of bar `i`. The fill happens at the OPEN of
 * bar `i + 1`. Never the close of bar `i`, never the open of bar `i`. If you
 * ever fill on the bar you decided on, you have invented edge that isn't there.
 *
 * On top of that, strategies physically cannot see the future: `ctx.bars` is a
 * guarded view that throws if the strategy reaches past the current bar.
 */

/**
 * Wrap `bars` so a strategy can only read up to and including `index`.
 * Reading beyond it throws — that's the no-lookahead guarantee, enforced by
 * the engine rather than by trust.
 */
export function createBarGuard(bars, index) {
  const limit = index + 1;
  return new Proxy(bars, {
    get(target, prop) {
      if (prop === 'length') return Math.min(target.length, limit);
      if (typeof prop === 'string' && /^\d+$/.test(prop)) {
        const i = Number(prop);
        if (i >= limit) {
          throw new Error(
            `lookahead blocked: strategy tried to read bar ${i} while standing on bar ${index}`,
          );
        }
      }
      return target[prop];
    },
  });
}

const bps = (v) => v / 10000;

/**
 * Run a backtest.
 *
 * @param {Array} bars  [{ time, open, high, low, close, volume }]
 * @param {Object} strategy  { name, params?, onBar(ctx) -> signal }
 * @param {Object} options   see ../config/defaults.js
 */
export function backtest(bars, strategy, options = {}) {
  const cfg = withDefaults(options);
  if (!Array.isArray(bars) || bars.length < 3) {
    throw new Error('backtest needs at least 3 bars');
  }
  if (!strategy || typeof strategy.onBar !== 'function') {
    throw new Error('strategy must be an object with an onBar(ctx) method');
  }

  let cash = cfg.initialEquity;
  let position = null;
  let pending = null;
  let totalDeposits = 0;

  // Deposits land at a specific bar so position sizing uses the capital that
  // was actually in the account at that moment.
  const depositsByBar = new Map();
  for (const d of cfg.deposits || []) {
    depositsByBar.set(d.barIndex, (depositsByBar.get(d.barIndex) || 0) + d.amount);
  }

  const trades = [];
  const equityCurve = [];
  const signals = [];
  const logs = [];
  let totalFees = 0;

  const log = (...args) => logs.push(args.map(String).join(' '));

  // ── helpers ────────────────────────────────────────────────────────────────
  const slip = (price, side) =>
    side === 'buy' ? price * (1 + bps(cfg.slippageBps)) : price * (1 - bps(cfg.slippageBps));

  const markEquity = (price) => {
    if (!position) return cash;
    return position.side === 'long'
      ? cash + position.size * price
      : cash - position.size * price;
  };

  const feeFor = (notional, isMaker) =>
    notional * (isMaker ? cfg.makerFee : cfg.takerFee);

  function openPosition(side, bar, index, signal) {
    const isBuy = side === 'long';
    const fill = slip(bar.open, isBuy ? 'buy' : 'sell');

    // A stop is mandatory: without one there's no honest way to size the trade.
    let stop = typeof signal.stop === 'number' ? signal.stop : null;
    let size = null;
    let riskAmount = 0;

    if (typeof signal.size === 'number' && signal.size > 0) {
      size = signal.size;
    } else if (typeof signal.notionalPct === 'number' && signal.notionalPct > 0) {
      // Explicit share of equity as notional — used by the buy-and-hold benchmark.
      size = ((cash * signal.notionalPct) / 100) / fill;
    } else if (stop !== null) {
      const stopDist = Math.abs(fill - stop);
      if (stopDist <= 0) return null;
      if (side === 'long' && stop >= fill) return null;  // stop above entry is nonsense
      if (side === 'short' && stop <= fill) return null;
      riskAmount = cash * (cfg.riskPct / 100);
      size = riskAmount / stopDist;
    } else {
      log(`skipped entry at bar ${index}: no stop and no size`);
      return null;
    }

    // L6 — never exceed the max notional for a single position
    const maxNotional = (cfg.maxNotionalPct / 100) * cash;
    let notional = size * fill;
    if (notional > maxNotional) {
      size = maxNotional / fill;
      notional = size * fill;
    }
    if (size <= 0) return null;

    const fee = feeFor(notional, true); // entry is a limit order → maker
    const entryNotional = notional;

    if (side === 'long') cash -= entryNotional + fee;
    else cash += entryNotional - fee;
    totalFees += fee;

    position = {
      side,
      size,
      entryPrice: fill,
      entryNotional,
      entryIndex: index,
      entryTime: bar.time,
      stop,
      target: typeof signal.target === 'number' ? signal.target : null,
      riskAmount,
      entryFee: fee,
      reason: signal.reason || '',
      maxFavorable: 0,
      maxAdverse: 0,
    };
    return position;
  }

  function closePosition(exitPrice, reason, bar, index) {
    if (!position) return;
    const isBuyToClose = position.side === 'short';
    const fill = slip(exitPrice, isBuyToClose ? 'buy' : 'sell');
    const gross = position.size * fill;
    // A stop-loss or signal exit is a market order → taker. A target exit can
    // rest as a limit → maker.
    const isMaker = reason === 'target';
    const fee = feeFor(gross, isMaker);
    totalFees += fee;

    let pnl;
    if (position.side === 'long') {
      cash += gross - fee;
      pnl = gross - position.entryNotional - position.entryFee - fee;
    } else {
      cash -= gross + fee;
      pnl = position.entryNotional - gross - position.entryFee - fee;
    }

    trades.push({
      side: position.side,
      entryTime: position.entryTime,
      exitTime: bar.time,
      entryIndex: position.entryIndex,
      exitIndex: index,
      entryPrice: position.entryPrice,
      exitPrice: fill,
      size: position.size,
      notional: position.entryNotional,
      pnl,
      fees: position.entryFee + fee,
      rMultiple: position.riskAmount > 0 ? pnl / position.riskAmount : null,
      exitReason: reason,
      barsHeld: index - position.entryIndex,
      thesis: position.reason,
    });
    position = null;
  }

  // ── main loop ──────────────────────────────────────────────────────────────
  for (let i = 0; i < bars.length; i++) {
    const bar = bars[i];

    // Bars before startIndex are warm-up only: the strategy still sees them so
    // its indicators are ready, but nothing may be opened or closed there.
    const live = i >= cfg.startIndex;

    // 0 ── capital deposited into the account on this bar
    if (depositsByBar.has(i)) {
      const amount = depositsByBar.get(i);
      cash += amount;
      totalDeposits += amount;
    }

    // 1 ── execute the order decided on the PREVIOUS bar, at THIS bar's open
    if (pending && live) {
      const act = pending;
      pending = null;
      if (act.action === 'enter_long' && !position) {
        openPosition('long', bar, i, act);
      } else if (act.action === 'enter_short' && !position && cfg.allowShort) {
        openPosition('short', bar, i, act);
      } else if (act.action === 'exit' && position) {
        closePosition(bar.open, 'signal', bar, i);
      }
    }

    // 2 ── intrabar stop / target, checked against THIS bar's range
    if (position) {
      const barsHeld = i - position.entryIndex;
      if (position.side === 'long') {
        const gapped = bar.open <= position.stop;
        if (gapped) {
          closePosition(bar.open, 'stop', bar, i);           // filled worse than the stop
        } else if (bar.low <= position.stop) {
          closePosition(position.stop, 'stop', bar, i);
        } else if (position.target !== null && bar.high >= position.target) {
          closePosition(position.target, 'target', bar, i);
        }
      } else {
        const gapped = bar.open >= position.stop;
        if (gapped) {
          closePosition(bar.open, 'stop', bar, i);
        } else if (bar.high >= position.stop) {
          closePosition(position.stop, 'stop', bar, i);
        } else if (position.target !== null && bar.low <= position.target) {
          closePosition(position.target, 'target', bar, i);
        }
      }
      if (position && barsHeld >= cfg.maxBarsInTrade) {
        closePosition(bar.close, 'time', bar, i);
      }
    }

    // 3 ── mark to market at this bar's close
    const equity = markEquity(bar.close);
    if (live) equityCurve.push({
      time: bar.time,
      equity,
      cash,
      inPosition: !!position,
      openPnl: position ? equity - cash : 0,
    });

    // 4 ── the strategy decides, seeing only up to and including this bar
    const guarded = createBarGuard(bars, i);
    const ctx = {
      bars: guarded,
      index: i,
      bar,
      position,
      equity,
      cash,
      params: strategy.params || {},
      log,
    };

    let signal;
    try {
      signal = strategy.onBar(ctx) || { action: 'hold' };
    } catch (err) {
      // A lookahead attempt is a strategy bug, not a runtime error — surface it verbatim.
      if (err && typeof err.message === 'string' && err.message.includes('lookahead blocked')) {
        throw err;
      }
      throw new Error(
        `strategy "${strategy.name || 'unnamed'}" threw at bar ${i}: ${err.message}`,
      );
    }

    signals.push({
      index: i,
      time: bar.time,
      action: signal.action || 'hold',
      reason: signal.reason || '',
    });

    if (live && signal.action && signal.action !== 'hold') {
      pending = { ...signal, decidedAtIndex: i };
    }
  }

  // ── close whatever is still open at the end of the data ────────────────────
  if (position) {
    const last = bars[bars.length - 1];
    closePosition(last.close, 'end_of_data', last, bars.length - 1);
    equityCurve[equityCurve.length - 1].equity = cash;
    equityCurve[equityCurve.length - 1].inPosition = false;
  }

  return {
    config: cfg,
    strategy: strategy.name || 'unnamed',
    bars: bars.length,
    start: bars[0].time,
    end: bars[bars.length - 1].time,
    initialEquity: cfg.initialEquity,
    finalEquity: cash,
    trades,
    equityCurve,
    signals,
    logs,
    totalFees,
    totalDeposits,
  };
}
