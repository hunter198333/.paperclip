import { backtest } from './backtest.js';
import { computeMetrics } from './metrics.js';

/**
 * Walk-forward analysis.
 *
 * Splits history into rolling in-sample / out-of-sample windows and stitches
 * the out-of-sample results together. The stitched result is the only number
 * you should ever trust — the in-sample number is where strategies go to die.
 */

/**
 * @param {Array} bars
 * @param {Function} makeStrategy  (params) => strategy
 * @param {Object} options
 *   windows      number of rolling windows (default 4)
 *   trainRatio   fraction of each window used for training (default 0.7)
 *   params       array of parameter sets to test per window
 */
export function walkForward(bars, makeStrategy, options = {}) {
  const {
    windows = 4,
    trainRatio = 0.7,
    params = [{}],
    minTrades = 30,
    ...backtestOptions
  } = options;

  if (bars.length < 50) {
    throw new Error('walk-forward needs at least 50 bars');
  }

  const windowSize = Math.floor(bars.length / windows);
  const folds = [];

  for (let w = 0; w < windows; w++) {
    const start = w * windowSize;
    const end = w === windows - 1 ? bars.length : start + windowSize;
    const slice = bars.slice(start, end);
    const split = Math.floor(slice.length * trainRatio);
    const train = slice.slice(0, split);
    const test = slice.slice(split);

    const inSample = [];
    for (const p of params) {
      const strategy = makeStrategy(p);
      if (!strategy) continue;
      const r = backtest(train, strategy, backtestOptions);
      const m = computeMetrics(r, { minTrades, ...backtestOptions });
      inSample.push({ params: p, metrics: m });
    }
    inSample.sort((a, b) => b.metrics.profitFactor - a.metrics.profitFactor);
    const best = inSample[0];

    const oos = best
      ? backtest(test, makeStrategy(best.params), backtestOptions)
      : null;
    const oosMetrics = oos ? computeMetrics(oos, { minTrades, ...backtestOptions }) : null;

    folds.push({
      fold: w + 1,
      trainBars: train.length,
      testBars: test.length,
      trainFrom: train[0]?.time,
      trainTo: train[train.length - 1]?.time,
      testFrom: test[0]?.time,
      testTo: test[test.length - 1]?.time,
      chosenParams: best?.params ?? null,
      inSample: best?.metrics ?? null,
      outOfSample: oosMetrics,
    });
  }

  // Stitch the out-of-sample segments into one equity path
  const oosTrades = folds.flatMap((f) => f.outOfSample?.trades ?? []);
  const stitched = folds
    .map((f) => f.outOfSample)
    .filter(Boolean);

  const totalOosTrades = oosTrades.length;
  const oosWins = oosTrades.filter((t) => t.pnl > 0).length;
  const oosProfit = oosTrades.reduce((s, t) => s + t.pnl, 0);
  const oosLoss = Math.abs(oosTrades.filter((t) => t.pnl <= 0).reduce((s, t) => s + t.pnl, 0));

  return {
    folds,
    stitched: {
      trades: totalOosTrades,
      winRate: totalOosTrades ? (oosWins / totalOosTrades) * 100 : 0,
      netProfit: oosProfit,
      profitFactor: oosLoss > 0 ? oosProfit / oosLoss : 0,
      foldsProfitable: stitched.filter((m) => m.netProfit > 0).length,
      foldsTotal: stitched.length,
    },
    verdict:
      totalOosTrades < minTrades
        ? `INSUFFICIENT SAMPLE — ${totalOosTrades} out-of-sample trades, need ${minTrades}. No conclusion.`
        : 'Out-of-sample sample size sufficient.',
  };
}
