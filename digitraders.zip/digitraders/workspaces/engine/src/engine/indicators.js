/**
 * Indicators — pure functions over arrays of numbers or bars.
 *
 * No dependencies on purpose: this has to run on a phone with nothing installed
 * but Node. Every function returns an array the same length as its input, with
 * `null` for the warm-up period, so you can index it by bar without offset bugs.
 */

/** Simple moving average. */
export function sma(values, period) {
  const out = new Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/** Exponential moving average (Wilder-style smoothing factor k = 2/(n+1)). */
export function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

/**
 * Average True Range (Wilder). True range accounts for gaps, which matters
 * a lot in crypto where a position can gap through its stop.
 */
export function atr(bars, period = 14) {
  const out = new Array(bars.length).fill(null);
  if (bars.length < period + 1) return out;
  const tr = new Array(bars.length).fill(0);
  tr[0] = bars[0].high - bars[0].low;
  for (let i = 1; i < bars.length; i++) {
    const prevClose = bars[i - 1].close;
    tr[i] = Math.max(
      bars[i].high - bars[i].low,
      Math.abs(bars[i].high - prevClose),
      Math.abs(bars[i].low - prevClose),
    );
  }
  let sum = 0;
  for (let i = 1; i <= period; i++) sum += tr[i];
  let prev = sum / period;
  out[period] = prev;
  for (let i = period + 1; i < bars.length; i++) {
    prev = (prev * (period - 1) + tr[i]) / period;
    out[i] = prev;
  }
  return out;
}

/** Relative Strength Index (Wilder). */
export function rsi(values, period = 14) {
  const out = new Array(values.length).fill(null);
  if (values.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

/** Rolling standard deviation (population). */
export function stdev(values, period) {
  const out = new Array(values.length).fill(null);
  for (let i = period - 1; i < values.length; i++) {
    let sum = 0;
    let sq = 0;
    for (let j = i - period + 1; j <= i; j++) {
      sum += values[j];
      sq += values[j] * values[j];
    }
    const mean = sum / period;
    out[i] = Math.sqrt(Math.max(0, sq / period - mean * mean));
  }
  return out;
}

/** Highest high over the last `period` bars (inclusive of the current bar). */
export function highest(bars, period, field = 'high') {
  const out = new Array(bars.length).fill(null);
  for (let i = period - 1; i < bars.length; i++) {
    let v = -Infinity;
    for (let j = i - period + 1; j <= i; j++) v = Math.max(v, bars[j][field]);
    out[i] = v;
  }
  return out;
}

/** Lowest low over the last `period` bars (inclusive of the current bar). */
export function lowest(bars, period, field = 'low') {
  const out = new Array(bars.length).fill(null);
  for (let i = period - 1; i < bars.length; i++) {
    let v = Infinity;
    for (let j = i - period + 1; j <= i; j++) v = Math.min(v, bars[j][field]);
    out[i] = v;
  }
  return out;
}

/** Percentage change between two values. */
export function pctChange(from, to) {
  if (!from) return 0;
  return ((to - from) / from) * 100;
}

/** Clamp a number into a range. */
export function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

/**
 * Incremental indicators.
 *
 * A live strategy can't recompute an SMA over the whole array every bar — it
 * maintains state. These classes do the same thing in O(1) per bar, which is
 * also what makes a backtest fast enough to iterate on.
 */

export class RollingSma {
  constructor(period) {
    this.period = period;
    this.buf = [];
    this.sum = 0;
  }

  /** Feed the next close, get the SMA (null during warm-up). */
  push(close) {
    this.buf.push(close);
    this.sum += close;
    if (this.buf.length > this.period) this.sum -= this.buf.shift();
    return this.buf.length === this.period ? this.sum / this.period : null;
  }

  get ready() {
    return this.buf.length >= this.period;
  }
}

export class RollingAtr {
  constructor(period = 14) {
    this.period = period;
    this.trs = [];
    this.prevClose = null;
    this.value = null;
  }

  /** Feed the next bar, get the ATR (null during warm-up). */
  push(bar) {
    let tr;
    if (this.prevClose === null) {
      tr = bar.high - bar.low;
    } else {
      tr = Math.max(
        bar.high - bar.low,
        Math.abs(bar.high - this.prevClose),
        Math.abs(bar.low - this.prevClose),
      );
    }
    this.prevClose = bar.close;
    this.trs.push(tr);

    if (this.trs.length === this.period) {
      this.value = this.trs.reduce((s, v) => s + v, 0) / this.period;
    } else if (this.trs.length > this.period) {
      this.value = (this.value * (this.period - 1) + tr) / this.period;
    }
    return this.value;
  }

  get ready() {
    return this.value !== null;
  }
}

/** Rolling window of the highest high / lowest low. */
export class RollingChannel {
  constructor(period) {
    this.period = period;
    this.highs = [];
    this.lows = [];
  }

  push(bar) {
    this.highs.push(bar.high);
    this.lows.push(bar.low);
    if (this.highs.length > this.period) { this.highs.shift(); this.lows.shift(); }
    return {
      highest: Math.max(...this.highs),
      lowest: Math.min(...this.lows),
      ready: this.highs.length === this.period,
    };
  }
}
