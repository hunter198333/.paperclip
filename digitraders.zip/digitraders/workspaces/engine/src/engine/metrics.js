/**
 * Performance metrics.
 *
 * The numbers that actually decide whether a strategy is worth running:
 * profit factor, max drawdown, expectancy, and — at small account sizes —
 * **how much of the account went to fees**.
 */

const BARS_PER_YEAR = {
  1: 525600, 5: 105120, 15: 35040, 30: 17520,
  60: 8760, 240: 2190, 1440: 365, 10080: 52, 21600: 12,
};

export function computeMetrics(result, options = {}) {
  const {
    minTrades = 30,
    intervalMinutes = 240,
  } = options;

  const { trades, equityCurve, initialEquity, totalFees } = result;

  // Capital contributed (starting balance + deposits). Trading P&L is measured
  // against this, so a paycheck deposit can never masquerade as a profit.
  const totalDeposits = result.totalDeposits ?? 0;
  const capitalBase = initialEquity + totalDeposits;

  const wins = trades.filter((t) => t.pnl > 0);
  const losses = trades.filter((t) => t.pnl <= 0);

  const grossProfit = wins.reduce((s, t) => s + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));
  const netProfit = grossProfit - grossLoss;
  // Equity comes from the curve (it includes deposits); P&L comes from the
  // trades (it never does).
  const finalEquity = equityCurve.length
    ? equityCurve[equityCurve.length - 1].equity
    : initialEquity + netProfit + totalDeposits;

  const avgWin = wins.length ? grossProfit / wins.length : 0;
  const avgLoss = losses.length ? grossLoss / losses.length : 0;

  const rMultiples = trades.map((t) => t.rMultiple).filter((r) => r !== null);
  const avgR = rMultiples.length ? rMultiples.reduce((s, r) => s + r, 0) / rMultiples.length : 0;

  // ── drawdown ───────────────────────────────────────────────────────────────
  let peak = equityCurve.length ? equityCurve[0].equity : initialEquity;
  let maxDD = 0;
  let maxDDPct = 0;
  let ddStart = 0;
  let maxDDDuration = 0;
  let curStart = 0;
  equityCurve.forEach((p, i) => {
    if (p.equity > peak) {
      peak = p.equity;
      curStart = i;
    }
    const dd = peak - p.equity;
    if (dd > maxDD) {
      maxDD = dd;
      maxDDPct = peak > 0 ? (dd / peak) * 100 : 0;
      ddStart = curStart;
    }
    const dur = i - curStart;
    if (dur > maxDDDuration) maxDDDuration = dur;
  });

  // ── sharpe from per-bar equity returns ─────────────────────────────────────
  const returns = [];
  for (let i = 1; i < equityCurve.length; i++) {
    const prev = equityCurve[i - 1].equity;
    if (prev > 0) returns.push((equityCurve[i].equity - prev) / prev);
  }
  let sharpe = null;
  if (returns.length > 2) {
    const mean = returns.reduce((s, r) => s + r, 0) / returns.length;
    const variance = returns.reduce((s, r) => s + (r - mean) ** 2, 0) / (returns.length - 1);
    const sd = Math.sqrt(variance);
    if (sd > 0) sharpe = (mean / sd) * Math.sqrt(BARS_PER_YEAR[intervalMinutes] || 365);
  }

  const exposureBars = equityCurve.filter((p) => p.inPosition).length;
  const exposure = equityCurve.length ? (exposureBars / equityCurve.length) * 100 : 0;
  const avgBarsHeld = trades.length
    ? trades.reduce((s, t) => s + t.barsHeld, 0) / trades.length
    : 0;

  const bestTrade = trades.reduce((b, t) => (!b || t.pnl > b.pnl ? t : b), null);
  const worstTrade = trades.reduce((b, t) => (!b || t.pnl < b.pnl ? t : b), null);

  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : (grossProfit > 0 ? Infinity : 0);

  return {
    totalTrades: trades.length,
    wins: wins.length,
    losses: losses.length,
    winRate: trades.length ? (wins.length / trades.length) * 100 : 0,

    initialEquity,
    totalDeposits,
    capitalBase,
    finalEquity,
    netProfit,
    netProfitPct: capitalBase > 0 ? (netProfit / capitalBase) * 100 : 0,

    grossProfit,
    grossLoss,
    profitFactor,
    avgWin,
    avgLoss,
    payoffRatio: avgLoss > 0 ? avgWin / avgLoss : null,
    expectancy: trades.length ? netProfit / trades.length : 0,
    expectancyR: avgR,

    avgR,
    bestTradeR: rMultiples.length ? Math.max(...rMultiples) : null,
    worstTradeR: rMultiples.length ? Math.min(...rMultiples) : null,

    maxDrawdown: maxDD,
    maxDrawdownPct: maxDDPct,
    maxDrawdownBars: maxDDDuration,

    sharpe,
    exposure,
    avgBarsHeld,

    totalFees,
    feesPctOfEquity: capitalBase > 0 ? (totalFees / capitalBase) * 100 : 0,
    avgFeePerTrade: trades.length ? totalFees / trades.length : 0,
    feesVsProfit: netProfit !== 0 ? totalFees / Math.abs(netProfit) : null,

    bestTrade,
    worstTrade,

    verdict:
      trades.length < minTrades
        ? `INSUFFICIENT SAMPLE — ${trades.length} trades, need ${minTrades}. No conclusion.`
        : 'Sample size sufficient.',
  };
}
