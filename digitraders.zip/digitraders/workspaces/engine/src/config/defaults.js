/**
 * Default configuration.
 *
 * Fee defaults are Kraken Pro **Tier 1** spot (30-day volume $0+):
 *   maker 0.40% / taker 0.80%  — raised 2026-07-09.
 * Check your own tier at https://www.kraken.com/features/fee-schedule
 */
export const KRAKEN_TIER1 = Object.freeze({
  makerFee: 0.004,
  takerFee: 0.008,
});

export const DEFAULTS = Object.freeze({
  /** Starting account equity in quote currency (USD). */
  initialEquity: 250,

  /** Risk per trade as a % of equity (policy L1). */
  riskPct: 0.5,

  /** Fees. Entry and target exits are maker (limit); stop and signal exits are taker (market). */
  makerFee: KRAKEN_TIER1.makerFee,
  takerFee: KRAKEN_TIER1.takerFee,
  stopExitIsTaker: true,

  /** Slippage against you, in basis points of price. */
  slippageBps: 5,

  /** Kraken spot only — no shorting, no margin, no leverage. */
  allowShort: false,

  /** Max notional for a single position as % of equity (policy L6). */
  maxNotionalPct: 25,

  /** Hard stop on how many bars a trade may stay open. */
  maxBarsInTrade: 2000,

  /** Below this many trades, a result is reported as "no conclusion" (policy L12). */
  minTradesForConclusion: 30,

  /**
   * Index of the first bar that may open a position. Bars before it are still
   * fed to the strategy (so indicators warm up), but their signals are ignored
   * and no position is opened. The paper-trading loop uses this so a paper
   * record starts fresh instead of inheriting backtest history.
   */
  startIndex: 0,

  /**
   * Capital added to the account, by bar index: [{ barIndex, amount }].
   * Deposits are tracked separately from trading P&L so that contributions
   * are never mistaken for performance.
   */
  deposits: [],
});

export const INTERVALS = Object.freeze({
  1: '1m', 5: '5m', 15: '15m', 30: '30m',
  60: '1h', 240: '4h', 1440: '1d', 10080: '1w', 21600: '30d',
});

export function withDefaults(options = {}) {
  return { ...DEFAULTS, ...options };
}
