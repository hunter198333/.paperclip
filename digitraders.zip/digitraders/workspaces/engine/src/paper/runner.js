import { backtest } from '../engine/backtest.js';
import { computeMetrics } from '../engine/metrics.js';
import { getStrategy } from '../strategies/index.js';
import { loadCandles } from '../data/store.js';
import {
  defaultState, loadState, saveState, resetState, resetPaper,
  appendToLedger, readLedger, writeStatus, writeCapitalLedger, LEDGER_FILE, STATUS_FILE,
} from './portfolio.js';

/**
 * The paper-trading cycle.
 *
 * One run = one full rehearsal of the desk's core loop:
 *   1. pull the latest candles from Kraken (public data, no key)
 *   2. run the strategy through the SAME engine that would place a real order
 *   3. keep only what happened since the paper record began
 *   4. log closed paper trades to the append-only ledger
 *   5. write the paper status file
 *
 * It never touches exchange keys and never places an order. That is not a
 * promise in the docs — it simply has no code path to an exchange write.
 */

const iso = (t) => new Date(t).toISOString();

export async function runPaperCycle(options = {}) {
  const {
    strategy: strategyName = 'sma-crossover',
    params = {},
    pair = 'XRPUSD',
    interval = 60,
    equity = 250,
    reset = false,
    refresh = true,
    paperStart = null,
    deposit = null,
    depositNote = '',
    makerFee = 0.004,
    takerFee = 0.008,
    slippageBps = 5,
    riskPct = 0.5,
    maxNotionalPct = 25,
    minTrades = 30,
  } = options;

  if (reset) resetPaper();

  let state = loadState();
  const fresh = !state;
  if (!state) {
    state = defaultState({ strategy: strategyName, params, pair, interval, equity });
    if (paperStart) state.paperStart = new Date(paperStart).toISOString();
  } else {
    // Keep the original paper start and equity — those define the record.
    state.strategy = strategyName;
    state.params = params;
    state.pair = pair;
    state.interval = interval;
  }

  // `bars` can be injected (tests, or an offline replay of a saved dataset)
  const loaded = options.bars
    ? { bars: options.bars, source: 'injected' }
    : await loadCandles({ pair: state.pair, interval: state.interval, refresh });
  const { bars, source } = loaded;
  if (bars.length < 3) throw new Error('not enough candles to run a paper cycle');

  // A new deposit lands in the account now.
  if (deposit && Number(deposit) > 0) {
    const amount = Number(deposit);
    state.deposits = state.deposits || [];
    state.deposits.push({
      date: new Date().toISOString(),
      amount: Number(amount.toFixed(2)),
      note: depositNote || 'deposit',
    });
  }

  // Where the paper record begins: the first bar at/after paperStart.
  const paperStartMs = Date.parse(state.paperStart);
  let startIndex = bars.findIndex((b) => b.time >= paperStartMs);
  if (startIndex === -1) startIndex = bars.length; // nothing new yet
  const isNew = startIndex < bars.length;

  // Map each deposit onto the first bar at/after it was made, so position
  // sizing uses the capital that was actually in the account at that moment.
  //
  // A deposit made after the last candle (e.g. you added money just now, but
  // the newest candle is from an hour ago) lands on the last bar — the cash is
  // real even if the bar isn't. Clamping to the last bar also keeps the deposit
  // inside the loop instead of silently dropping it.
  const deposits = (state.deposits || []).map((d) => {
    const t = Date.parse(d.date);
    let idx = bars.findIndex((b) => b.time >= t);
    if (idx === -1) idx = bars.length - 1;
    return { barIndex: Math.min(Math.max(idx, 0), bars.length - 1), amount: d.amount };
  });

  const strategy = getStrategy(state.strategy, state.params);
  const result = backtest(bars, strategy, {
    initialEquity: state.initialEquity,
    riskPct,
    makerFee,
    takerFee,
    slippageBps,
    maxNotionalPct,
    startIndex,
    deposits,
  });

  // Only trades opened after the paper start count, and only ones we haven't
  // already written to the ledger.
  const paperTrades = result.trades.map((t) => ({ ...t, pair: state.pair }));
  const newTrades = paperTrades.slice(state.recordedTrades);

  if (newTrades.length) {
    appendToLedger(newTrades);
    state.recordedTrades = paperTrades.length;
  }

  // Benchmark over the same window, for an honest comparison
  // Same constraints as the strategy — otherwise you're comparing a capped
  // strategy against an uncapped benchmark, which is not a comparison.
  const bench = backtest(bars, getStrategy('buy-and-hold'), {
    initialEquity: state.initialEquity,
    makerFee, takerFee, slippageBps, maxNotionalPct,
    startIndex,
    deposits,
  });

  const metrics = computeMetrics(
    { ...result, trades: paperTrades },
    { minTrades, intervalMinutes: state.interval },
  );
  const benchMetrics = computeMetrics(bench, { minTrades, intervalMinutes: state.interval });

  const lastBar = bars[bars.length - 1];
  const newBar = !state.lastBarTime || lastBar.time > state.lastBarTime;

  state.lastCycleAt = new Date().toISOString();
  state.lastBarTime = lastBar.time;
  state.paperStart = state.paperStart;
  saveState(state);

  const paperEquity = metrics.finalEquity;
  const benchEquity = benchMetrics.finalEquity;

  const status = {
    state,
    fresh,
    isNew,
    newBar,
    source,
    bars: bars.length,
    startIndex,
    paperTrades,
    newTrades,
    metrics,
    benchMetrics,
    equity: paperEquity,
    benchEquity,
    edge: metrics.netProfit - benchMetrics.netProfit,
    openPosition: result.equityCurve.length
      ? result.equityCurve[result.equityCurve.length - 1].inPosition
      : false,
    ledgerRows: readLedger().length,
    lastBarTime: lastBar.time,
    deposits: state.deposits || [],
    totalDeposited: metrics.totalDeposits,
    capitalBase: metrics.capitalBase,
  };

  writeStatus(renderStatusMarkdown(status));
  writeCapitalLedger(status);

  return status;
}

function fmtDate(t) {
  if (!t) return '—';
  return iso(t).replace('T', ' ').slice(0, 16);
}

function renderStatusMarkdown(s) {
  const m = s.metrics;
  const b = s.benchMetrics;
  const money = (v) => `${v < 0 ? '-' : ''}$${Math.abs(v).toFixed(2)}`;
  const pct = (v) => `${v.toFixed(2)}%`;

  return `# Paper Trading Status

_Auto-generated by the paper cycle. Do not edit by hand — the next cycle overwrites this file._
_The agent-maintained board is \`docs/status-board.md\`._

**Strategy:** ${s.state.strategy} ${JSON.stringify(s.state.params)}  
**Pair:** ${s.state.pair} · **Timeframe:** ${s.state.interval}m  
**Paper started:** ${fmtDate(s.state.paperStart)}  
**Last cycle:** ${fmtDate(s.state.lastCycleAt)}  
**Last candle:** ${fmtDate(s.lastBarTime)}  

## Where we are

| Metric | Value | Benchmark (buy & hold) |
|---|---|---|
| **Total capital in the account** | **${money(s.capitalBase)}** | ${money(s.capitalBase)} |
| Deposited (your money in) | ${money(s.totalDeposited)} | ${money(s.totalDeposited)} |
| **Trading P&L** | **${money(m.netProfit)}** (${pct(m.netProfitPct)} of capital) | ${money(b.netProfit)} (${pct(b.netProfitPct)}) |
| Total equity | ${money(s.equity)} | ${money(s.benchEquity)} |
| Edge vs benchmark | **${s.edge >= 0 ? '+' : ''}${money(s.edge)}** | — |
| Trades | ${m.totalTrades} | ${b.totalTrades} |
| Win rate | ${pct(m.winRate)} | ${pct(b.winRate)} |
| Profit factor | ${Number.isFinite(m.profitFactor) ? m.profitFactor.toFixed(2) : '∞'} | ${Number.isFinite(b.profitFactor) ? b.profitFactor.toFixed(2) : '∞'} |
| Max drawdown | ${pct(m.maxDrawdownPct)} | ${pct(b.maxDrawdownPct)} |
| Fees paid | ${money(m.totalFees)} | ${money(b.totalFees)} |
| Exposure | ${pct(m.exposure)} | ${pct(b.exposure)} |

**Verdict:** ${m.verdict}

> **Read the two numbers separately.** Deposited capital is your paycheck — it is not
> a return. Trading P&L is the only line that measures the desk. A growing account
> with flat trading P&L means the desk isn't working yet.

## Recent paper trades

${s.paperTrades.length === 0 ? '_No paper trades yet._' : s.paperTrades.slice(-10).reverse().map((t) => `- ${fmtDate(t.exitTime)} · ${t.side} · ${t.pnl >= 0 ? '+' : ''}$${Math.abs(t.pnl).toFixed(2)} · ${t.exitReason}`).join('\n')}

Full ledger: \`docs/trading/journal/paper-ledger.md\` (${s.ledgerRows} rows)
`;
}

export { LEDGER_FILE, STATUS_FILE };
