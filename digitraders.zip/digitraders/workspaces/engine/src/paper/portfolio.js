import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

/**
 * Paths. Overridable with env vars so tests can run against a temp directory
 * and so a future "second desk" can keep its own record.
 */
const env = (name, fallback) => process.env[name] || fallback;

/** Engine-local state. Git-ignored. */
export const STATE_DIR = path.resolve(env('DIGITRADERS_PAPER_STATE_DIR', path.resolve(here, '..', '..', '.paper')));
export const STATE_FILE = path.join(STATE_DIR, 'state.json');

/** The human-readable, append-only paper trade ledger. */
export const LEDGER_FILE = path.resolve(env(
  'DIGITRADERS_PAPER_LEDGER',
  path.resolve(here, '..', '..', '..', '..', 'docs', 'trading', 'journal', 'paper-ledger.md'),
));

/** The capital ledger — what went in, and when. */
export const CAPITAL_FILE = path.resolve(env(
  'DIGITRADERS_PAPER_CAPITAL',
  path.resolve(here, '..', '..', '..', '..', 'docs', 'trading', 'capital.md'),
));

/** Auto-generated paper status, separate from the agent-maintained board. */
export const STATUS_FILE = path.resolve(env(
  'DIGITRADERS_PAPER_STATUS',
  path.resolve(here, '..', '..', '..', '..', 'docs', 'trading', 'paper-status.md'),
));

export function defaultState({ strategy, params = {}, pair, interval, equity }) {
  return {
    version: 1,
    strategy,
    params,
    pair,
    interval,
    initialEquity: equity,
    paperStart: new Date().toISOString(),
    lastCycleAt: null,
    lastBarTime: null,
    recordedTrades: 0,
  };
}

export function loadState() {
  if (!fs.existsSync(STATE_FILE)) return null;
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return null;
  }
}

export function saveState(state) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  return STATE_FILE;
}

export function resetState() {
  if (fs.existsSync(STATE_DIR)) fs.rmSync(STATE_DIR, { recursive: true, force: true });
  return STATE_DIR;
}

/**
 * Full reset: state AND ledger. The ledger is append-only in normal operation,
 * but an explicit reset is an operator action on a simulated record, so it
 * clears both — otherwise the next cycle would re-log old trades.
 */
export function resetPaper() {
  resetState();
  if (fs.existsSync(LEDGER_FILE)) fs.writeFileSync(LEDGER_FILE, LEDGER_HEADER);
  return { state: STATE_DIR, ledger: LEDGER_FILE };
}

const LEDGER_HEADER = `# Paper Trade Ledger

Append-only. One row per **closed** paper trade. Written by the paper cycle
(\`node src/cli.js paper\`). Never edit or delete a row — corrections are new rows.

A paper trade is a simulated fill produced by the same engine that would place a
real one. It is a rehearsal, not a profit.

| Closed (UTC) | Pair | Side | Entry | Exit | Size | P&L | Fees | R | Exit reason |
|---|---|---|---|---|---|---|---|---|---|
`;

/** Identity of a ledger row — used to stop the same trade being logged twice. */
function tradeKey(t) {
  return [
    new Date(t.exitTime).toISOString(),
    t.pair ?? '',
    t.side,
    t.entryPrice.toFixed(8),
    t.exitPrice.toFixed(8),
  ].join('|');
}

/** Keys already present in the ledger. */
function existingKeys() {
  if (!fs.existsSync(LEDGER_FILE)) return new Set();
  const keys = new Set();
  for (const line of fs.readFileSync(LEDGER_FILE, 'utf8').split('\n')) {
    if (!line.startsWith('| ') || line.includes('| Closed')) continue;
    const c = line.split('|').map((s) => s.trim()).filter((s) => s.length);
    if (c.length < 9) continue;
    keys.add([c[0], c[1], c[2], c[3], c[4]].join('|'));
  }
  return keys;
}

/** Append closed paper trades to the ledger. Returns how many rows were added. */
export function appendToLedger(trades) {
  if (!trades.length) return 0;
  fs.mkdirSync(path.dirname(LEDGER_FILE), { recursive: true });
  if (!fs.existsSync(LEDGER_FILE)) {
    fs.writeFileSync(LEDGER_FILE, LEDGER_HEADER);
  }
  const seen = existingKeys();
  const fresh = trades.filter((t) => {
    const k = tradeKey(t);
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  if (!fresh.length) return 0;
  const rows = fresh.map((t) => {
    const closed = new Date(t.exitTime).toISOString().replace('T', ' ').slice(0, 16);
    const r = t.rMultiple === null ? '—' : `${t.rMultiple.toFixed(2)}R`;
    const pnl = `${t.pnl >= 0 ? '+' : '-'}$${Math.abs(t.pnl).toFixed(2)}`;
    const fees = `$${t.fees.toFixed(2)}`;
    return `| ${closed} | ${t.pair ?? ''} | ${t.side} | ${t.entryPrice.toFixed(6)} | ${t.exitPrice.toFixed(6)} | ${t.size.toFixed(6)} | ${pnl} | ${fees} | ${r} | ${t.exitReason} |`;
  });
  fs.appendFileSync(LEDGER_FILE, rows.join('\n') + '\n');
  return rows.length;
}

/** Read the ledger back for reporting. */
export function readLedger() {
  if (!fs.existsSync(LEDGER_FILE)) return [];
  return fs
    .readFileSync(LEDGER_FILE, 'utf8')
    .split('\n')
    .filter((l) => l.startsWith('| ') && !l.includes('| Closed'))
    .map((l) => {
      const c = l.split('|').map((s) => s.trim()).filter((s) => s.length);
      return { closed: c[0], pair: c[1], side: c[2], pnl: c[6], fees: c[7], exitReason: c[9] };
    });
}

/**
 * The capital ledger.
 *
 * Capital you put in is NOT profit. This file keeps the two apart so the
 * status page can always answer "how much of this did trading actually make?"
 */
export function writeCapitalLedger(state) {
  const deposits = state.deposits || [];
  let running = state.state.initialEquity;
  const rows = deposits.map((d) => {
    running += d.amount;
    const date = d.date.slice(0, 10);
    return `| ${date} | $${d.amount.toFixed(2)} | $${running.toFixed(2)} | ${d.note} |`;
  });

  const content = `# Capital Ledger

_Generated by the paper cycle. This file records **money going in** — it is not a
performance record. Trading results live in \`paper-status.md\`._

**Started:** ${state.state.paperStart.slice(0, 10)}  
**Starting capital:** $${state.state.initialEquity.toFixed(2)}  
**Total deposited:** $${(state.totalDeposited || 0).toFixed(2)}  
**Total capital in the account:** $${(state.capitalBase || 0).toFixed(2)}

| Date | Amount | Running total | Note |
|---|---|---|---|
| ${state.state.paperStart.slice(0, 10)} | $${state.state.initialEquity.toFixed(2)} | $${state.state.initialEquity.toFixed(2)} | starting capital |
${rows.join('\n')}

> Deposits grow the account. They are not a return. The only number that measures
> the desk is **trading P&L ÷ total capital** — see \`paper-status.md\`.
`;
  fs.mkdirSync(path.dirname(CAPITAL_FILE), { recursive: true });
  fs.writeFileSync(CAPITAL_FILE, content);
  return CAPITAL_FILE;
}

/** Write the auto-generated paper status file. */
export function writeStatus(markdown) {
  fs.mkdirSync(path.dirname(STATUS_FILE), { recursive: true });
  fs.writeFileSync(STATUS_FILE, markdown);
  return STATUS_FILE;
}
