import { makeSmaCrossover } from './sma-crossover.js';
import { makeAtrBreakout } from './atr-breakout.js';
import { makeBuyAndHold } from './buy-and-hold.js';

/**
 * Strategy registry.
 *
 * `hypothesis` is the sentence you'd write in the experiment log before you
 * run it. If you can't write one, don't run it.
 */
export const STRATEGIES = {
  'buy-and-hold': {
    factory: makeBuyAndHold,
    description: 'All-in from bar 0 and hold. The benchmark everything else must beat.',
    hypothesis: 'The asset rises over this period.',
    params: [{ notionalPct: 100 }],
  },
  'sma-crossover': {
    factory: makeSmaCrossover,
    description: 'Fast/slow SMA cross in, ATR-based stop, cross out.',
    hypothesis: 'Multi-hour trends persist, so a moving-average cross captures part of the move.',
    params: [
      { fast: 10, slow: 50 },
      { fast: 20, slow: 100 },
      { fast: 50, slow: 200 },
    ],
  },
  'atr-breakout': {
    factory: makeAtrBreakout,
    description: 'Donchian breakout with an ATR stop and a channel exit.',
    hypothesis: 'A break of the N-bar range starts a move that continues.',
    params: [
      { channel: 10, stopAtrMult: 2 },
      { channel: 20, stopAtrMult: 2 },
      { channel: 55, stopAtrMult: 3 },
    ],
  },
};

export function getStrategy(name, params = {}) {
  const entry = STRATEGIES[name];
  if (!entry) {
    throw new Error(`unknown strategy "${name}". Available: ${Object.keys(STRATEGIES).join(', ')}`);
  }
  return entry.factory(params);
}

export function listStrategies() {
  return Object.entries(STRATEGIES).map(([name, s]) => ({
    name,
    description: s.description,
    hypothesis: s.hypothesis,
    params: s.params,
  }));
}
