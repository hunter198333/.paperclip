import { RollingSma, RollingAtr } from '../engine/indicators.js';

/**
 * SMA crossover — the baseline trend-following strategy.
 *
 * HYPOTHESIS: price trends persist over multi-hour horizons, so a fast/slow
 * moving-average cross captures part of the move.
 *
 * HONEST WARNING: this is a textbook baseline, not an edge. Its job is to give
 * you something to beat. If your idea can't beat this after fees, it isn't an
 * idea yet.
 */
export function makeSmaCrossover(params = {}) {
  const p = { fast: 20, slow: 100, atrPeriod: 14, stopAtrMult: 1.5, targetR: 2, ...params };
  const fastSma = new RollingSma(p.fast);
  const slowSma = new RollingSma(p.slow);
  const atr = new RollingAtr(p.atrPeriod);
  let prevFast = null;
  let prevSlow = null;

  return {
    name: 'sma-crossover',
    params: p,
    onBar(ctx) {
      const f = fastSma.push(ctx.bar.close);
      const s = slowSma.push(ctx.bar.close);
      const a = atr.push(ctx.bar);
      const crossedUp = prevFast !== null && prevSlow !== null && prevFast <= prevSlow && f > s;
      const crossedDown = prevFast !== null && prevSlow !== null && prevFast >= prevSlow && f < s;
      prevFast = f;
      prevSlow = s;

      if (!f || !s || !a) return { action: 'hold' };

      if (ctx.position && ctx.position.side === 'long' && crossedDown) {
        return { action: 'exit', reason: `fast SMA crossed below slow SMA (${f.toFixed(4)} < ${s.toFixed(4)})` };
      }

      if (!ctx.position && crossedUp) {
        const stop = ctx.bar.close - p.stopAtrMult * a;
        const target = ctx.bar.close + p.targetR * p.stopAtrMult * a;
        return {
          action: 'enter_long',
          stop,
          target,
          reason: `fast SMA crossed above slow SMA (${f.toFixed(4)} > ${s.toFixed(4)}), ATR ${a.toFixed(4)}`,
        };
      }

      return { action: 'hold' };
    },
  };
}
