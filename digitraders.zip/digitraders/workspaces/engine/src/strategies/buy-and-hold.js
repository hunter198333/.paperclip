/**
 * Buy and hold — the benchmark.
 *
 * HYPOTHESIS: the asset goes up (or it doesn't).
 *
 * This is the number every strategy has to beat, after fees. If your strategy
 * can't beat "do nothing" on the same period with the same money, you don't
 * have a strategy — you have a hobby.
 */
export function makeBuyAndHold(params = {}) {
  const p = { notionalPct: 100, ...params };
  return {
    name: 'buy-and-hold',
    params: p,
    onBar(ctx) {
      // Stay invested. If the engine's time cap ever closes the position, get
      // straight back in — this is the benchmark, and a benchmark that sits in
      // cash half the time isn't a benchmark.
      if (!ctx.position) {
        return {
          action: 'enter_long',
          notionalPct: p.notionalPct,
          reason: 'benchmark: all-in',
        };
      }
      return { action: 'hold' };
    },
  };
}
