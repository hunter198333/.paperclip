import { RollingAtr, RollingChannel } from '../engine/indicators.js';

/**
 * Donchian breakout with an ATR stop.
 *
 * HYPOTHESIS: a pair that breaks its N-bar range is in a directional move that
 * tends to continue for a while.
 *
 * Honest note: breakout systems love backtests and hate live trading — the
 * breakout bar itself has worse fill prices than the backtest assumes. That's
 * exactly what the fee + slippage model here is for.
 */
export function makeAtrBreakout(params = {}) {
  const p = { channel: 20, atrPeriod: 14, stopAtrMult: 2, exitChannel: 10, ...params };
  const channel = new RollingChannel(p.channel);
  const exitChannel = new RollingChannel(p.exitChannel);
  const atr = new RollingAtr(p.atrPeriod);

  return {
    name: 'atr-breakout',
    params: p,
    onBar(ctx) {
      const ch = channel.push(ctx.bar);
      const ex = exitChannel.push(ctx.bar);
      const a = atr.push(ctx.bar);
      if (!ch.ready || !ex.ready || !a) return { action: 'hold' };

      // Breakout: close above the prior channel high (use the previous bar's
      // channel so we don't compare the current bar to itself).
      const prevHigh = ctx.index > 0 ? ctx.bars[ctx.index - 1].high : null;
      const prevLow = ctx.index > 0 ? ctx.bars[ctx.index - 1].low : null;
      if (prevHigh === null) return { action: 'hold' };

      if (ctx.position && ctx.position.side === 'long') {
        if (ctx.bar.close < ex.lowest) {
          return { action: 'exit', reason: `close ${ctx.bar.close.toFixed(4)} fell below ${p.exitChannel}-bar low ${ex.lowest.toFixed(4)}` };
        }
        return { action: 'hold' };
      }

      if (!ctx.position && ctx.bar.close > prevHigh && ctx.bar.close > ch.highest) {
        const stop = ctx.bar.close - p.stopAtrMult * a;
        return {
          action: 'enter_long',
          stop,
          reason: `close ${ctx.bar.close.toFixed(4)} broke the ${p.channel}-bar high ${ch.highest.toFixed(4)}`,
        };
      }
      if (!ctx.position && ctx.bar.close < prevLow && ctx.bar.close < ch.lowest) {
        const stop = ctx.bar.close + p.stopAtrMult * a;
        return {
          action: 'enter_short',
          stop,
          reason: `close ${ctx.bar.close.toFixed(4)} broke the ${p.channel}-bar low ${ch.lowest.toFixed(4)}`,
        };
      }

      return { action: 'hold' };
    },
  };
}
