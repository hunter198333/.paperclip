#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { backtest } from './engine/backtest.js';
import { computeMetrics } from './engine/metrics.js';
import { walkForward } from './engine/walkforward.js';
import { STRATEGIES, getStrategy, listStrategies } from './strategies/index.js';
import { loadCandles } from './data/store.js';
import { loadCsv } from './data/csv.js';
import { fetchTicker } from './data/kraken.js';
import { runPaperCycle } from './paper/runner.js';

const RESET = '\x1b[0m';
const BOLD = '\x1b[1m';
const DIM = '\x1b[2m';
const RED = '\x1b[31m';
const GREEN = '\x1b[32m';
const YELLOW = '\x1b[33m';

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) {
        args[key] = true;
      } else {
        args[key] = next;
        i++;
      }
    } else {
      args._.push(a);
    }
  }
  return args;
}

const num = (v, d) => (v === undefined ? d : Number(v));
const money = (v) => `${v < 0 ? '-' : ''}$${Math.abs(v).toFixed(2)}`;
const pct = (v) => `${v.toFixed(2)}%`;
const num2 = (v, d = 2) => (v === null || v === undefined || Number.isNaN(v) ? 'n/a' : v.toFixed(d));

function line(label, a, b) {
  return `  ${String(label).padEnd(18)}${String(a).padEnd(16)}${b}`;
}

async function loadBars(args) {
  if (args.csv) {
    const bars = loadCsv(args.csv);
    return { bars, source: `csv:${path.basename(args.csv)}` };
  }
  const { bars, source } = await loadCandles({
    pair: args.pair || 'XRPUSD',
    interval: num(args.interval, 240),
    refresh: !!args.refresh,
  });
  return { bars, source };
}

function printReport(result, metrics, args) {
  const L = console.log;
  L('');
  L(`${BOLD}════════════════════════════════════════════════════════════════${RESET}`);
  L(`${BOLD}  BACKTEST — ${result.strategy}${RESET}`);
  L(`${BOLD}════════════════════════════════════════════════════════════════${RESET}`);
  L(`  ${DIM}period${RESET}     ${new Date(result.start).toISOString().slice(0, 10)} → ${new Date(result.end).toISOString().slice(0, 10)}   ${result.bars} bars`);
  L(`  ${DIM}account${RESET}     ${money(result.initialEquity)}   ${DIM}fees: ${(result.config.makerFee * 100).toFixed(2)}% maker / ${(result.config.takerFee * 100).toFixed(2)}% taker${RESET}`);
  L('');
  L(`${BOLD}  RESULTS${RESET}`);
  L(line('trades', metrics.totalTrades, `win rate      ${pct(metrics.winRate)}`));
  L(line('net profit', money(metrics.netProfit), `net %         ${pct(metrics.netProfitPct)}`));
  L(line('profit factor', num2(metrics.profitFactor), `avg R         ${num2(metrics.avgR)}`));
  L(line('max drawdown', money(metrics.maxDrawdown), `max DD %      ${pct(metrics.maxDrawdownPct)}`));
  L(line('total fees', money(metrics.totalFees), `fees as %     ${pct(metrics.feesPctOfEquity)}`));
  L(line('exposure', pct(metrics.exposure), `sharpe        ${num2(metrics.sharpe)}`));
  L(line('avg hold', `${metrics.avgBarsHeld.toFixed(1)} bars`, `final equity  ${money(metrics.finalEquity)}`));
  L('');

  if (metrics.totalTrades === 0) {
    L(`  ${YELLOW}No trades were taken.${RESET} The strategy never signalled, or every signal was rejected.`);
  }

  const insufficient = metrics.verdict.startsWith('INSUFFICIENT');
  if (insufficient) {
    L(`  ${YELLOW}⚠  ${metrics.verdict}${RESET}`);
    L(`  ${DIM}   A strategy with fewer than 30 trades tells you nothing. Treat this as a data point,${RESET}`);
    L(`  ${DIM}   not as an edge. Log it in docs/trading/experiments.md and move on.${RESET}`);
  }

  if (metrics.feesVsProfit !== null && metrics.netProfit > 0) {
    L(`  ${DIM}   fees were ${pct(metrics.feesVsProfit * 100)} of your net profit.${RESET}`);
  }
  if (metrics.totalFees > Math.abs(metrics.netProfit) && metrics.totalTrades > 0) {
    L(`  ${YELLOW}   fees (${money(metrics.totalFees)}) exceeded net profit (${money(metrics.netProfit)}).${RESET}`);
    L(`  ${DIM}   The edge, if there is one, is smaller than the cost of finding it.${RESET}`);
  }
  L('');
}

async function cmdBacktest(args) {
  const { bars, source } = await loadBars(args);
  const name = args.strategy || 'sma-crossover';
  const cfg = {
    initialEquity: num(args.equity, 250),
    riskPct: num(args.risk, 0.5),
    makerFee: num(args.makerFee, 0.004),
    takerFee: num(args.takerFee, 0.008),
    slippageBps: num(args.slippage, 5),
    maxNotionalPct: num(args.maxNotional, 25),
    allowShort: args.short === true,
  };

  const strategy = getStrategy(name);
  const result = backtest(bars, strategy, cfg);
  const metrics = computeMetrics(result, { minTrades: num(args.minTrades, 30), intervalMinutes: num(args.interval, 240) });

  console.log(`  ${DIM}data${RESET}      ${source}  ${DIM}(${bars.length} bars)${RESET}`);
  printReport(result, metrics, args);

  // Benchmark comparison — the number that actually matters
  if (name !== 'buy-and-hold' && !args.noBenchmark) {
    const bh = backtest(bars, getStrategy('buy-and-hold'), cfg);
    const bhMetrics = computeMetrics(bh, { minTrades: num(args.minTrades, 30) });
    const edge = metrics.netProfit - bhMetrics.netProfit;
    console.log(`  ${BOLD}VS BUY-AND-HOLD${RESET}`);
    console.log(line('strategy', money(metrics.netProfit), `benchmark   ${money(bhMetrics.netProfit)}`));
    console.log(line('edge', `${edge >= 0 ? '+' : ''}${money(edge)}`, `benchmark DD ${pct(bhMetrics.maxDrawdownPct)}`));
    if (edge <= 0) {
      console.log(`  ${YELLOW}   Your strategy did not beat simply holding the asset. That is the bar.${RESET}`);
    }
    console.log('');
  }

  if (args.out) {
    const payload = {
      strategy: name,
      params: strategy.params,
      config: result.config,
      dataSource: source,
      period: { start: result.start, end: result.end, bars: result.bars },
      metrics,
      trades: result.trades,
      equityCurve: result.equityCurve,
    };
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    fs.writeFileSync(path.resolve(args.out), JSON.stringify(payload, null, 2));
    console.log(`  ${DIM}results written to ${args.out}${RESET}\n`);
  }

  const insufficient = metrics.totalTrades < num(args.minTrades, 30);
  process.exit(insufficient && !args.force ? 2 : 0);
}

async function cmdWalkForward(args) {
  const { bars, source } = await loadBars(args);
  const name = args.strategy || 'sma-crossover';
  const entry = STRATEGIES[name];
  if (!entry) throw new Error(`unknown strategy "${name}"`);

  const wf = walkForward(bars, (p) => entry.factory(p), {
    windows: num(args.windows, 4),
    trainRatio: num(args.trainRatio, 0.7),
    params: entry.params,
    minTrades: num(args.minTrades, 30),
    initialEquity: num(args.equity, 250),
    riskPct: num(args.risk, 0.5),
    makerFee: num(args.makerFee, 0.004),
    takerFee: num(args.takerFee, 0.008),
    slippageBps: num(args.slippage, 5),
  });

  console.log(`  ${DIM}data${RESET} ${source}  ${DIM}(${bars.length} bars)${RESET}`);
  console.log('');
  console.log(`${BOLD}  WALK-FORWARD — ${name}${RESET}`);
  console.log('');
  for (const f of wf.folds) {
    const ins = f.inSample;
    const oos = f.outOfSample;
    console.log(`  ${BOLD}fold ${f.fold}${RESET}  train ${f.trainBars} bars → test ${f.testBars} bars`);
    console.log(`    ${DIM}params${RESET}      ${JSON.stringify(f.chosenParams)}`);
    if (ins) {
      console.log(`    ${DIM}in-sample${RESET}   ${ins.totalTrades} trades · PF ${num2(ins.profitFactor)} · ${money(ins.netProfit)} · DD ${pct(ins.maxDrawdownPct)}`);
    }
    if (oos) {
      const colour = oos.netProfit > 0 ? GREEN : RED;
      console.log(`    ${DIM}OUT-OF-SAMPLE${RESET} ${oos.totalTrades} trades · PF ${num2(oos.profitFactor)} · ${colour}${money(oos.netProfit)}${RESET} · DD ${pct(oos.maxDrawdownPct)}`);
    }
    console.log('');
  }
  console.log(`${BOLD}  STITCHED OUT-OF-SAMPLE${RESET}`);
  console.log(line('trades', wf.stitched.trades, `win rate      ${pct(wf.stitched.winRate)}`));
  console.log(line('net profit', money(wf.stitched.netProfit), `profit factor ${num2(wf.stitched.profitFactor)}`));
  console.log(line('profitable folds', `${wf.stitched.foldsProfitable}/${wf.stitched.foldsTotal}`, ''));
  console.log('');
  console.log(`  ${wf.verdict.startsWith('INSUFFICIENT') ? YELLOW : DIM}  ${wf.verdict}${RESET}`);
  console.log('');
}

function printPaperReport(s) {
  const L = console.log;
  const m = s.metrics;
  const b = s.benchMetrics;
  const money = (v) => `${v < 0 ? '-' : ''}$${Math.abs(v).toFixed(2)}`;
  const pct = (v) => `${v.toFixed(2)}%`;

  L('');
  L(`${BOLD}════════════════════════════════════════════════════════════════${RESET}`);
  L(`${BOLD}  PAPER CYCLE — ${s.state.strategy} · ${s.state.pair} · ${s.state.interval}m${RESET}`);
  L(`${BOLD}════════════════════════════════════════════════════════════════${RESET}`);
  L(`  ${DIM}candle${RESET}      ${new Date(s.lastBarTime).toISOString().replace('T', ' ').slice(0, 16)}   ${s.newBar ? 'NEW' : 'no new candle'}`);
  L(`  ${DIM}paper start${RESET}  ${s.state.paperStart.replace('T', ' ').slice(0, 16)}   ${s.fresh ? '(new record)' : `${s.bars} bars available`}`);
  L('');
  L(`${BOLD}  CAPITAL${RESET}`);
  L(line('capital in', money(s.capitalBase), `deposited  ${money(s.totalDeposited)}`));
  L(line('trading p&l', money(m.netProfit), `of capital ${pct(m.netProfitPct)}`));
  L(line('total equity', money(s.equity), `benchmark  ${money(s.benchEquity)}`));
  L(line('edge', `${s.edge >= 0 ? '+' : ''}${money(s.edge)}`, `vs buy&hold`));
  L('');
  L(`${BOLD}  PERFORMANCE${RESET}`);
  L(line('trades', m.totalTrades, `win rate    ${pct(m.winRate)}`));
  L(line('profit factor', Number.isFinite(m.profitFactor) ? m.profitFactor.toFixed(2) : 'inf', `max DD      ${pct(m.maxDrawdownPct)}`));
  L(line('fees', money(m.totalFees), `exposure    ${pct(m.exposure)}`));
  L('');
  L(`  ${DIM}deposits are your money going in — they are not a return.${RESET}`);
  L(`  ${DIM}The trading P&L line is the only one that measures the desk.${RESET}`);
  L('');
  if (s.newTrades.length) {
    L(`  ${GREEN}${s.newTrades.length} paper trade(s) closed and logged:${RESET}`);
    for (const t of s.newTrades) {
      L(`    ${new Date(t.exitTime).toISOString().replace('T', ' ').slice(0, 16)}  ${t.side.padEnd(5)}  ${t.pnl >= 0 ? '+' : ''}${money(t.pnl)}  ${t.exitReason}`);
    }
  } else {
    L(`  ${DIM}no new paper trades — nothing to log.${RESET}`);
  }
  L('');
  L(`  ${DIM}ledger: docs/trading/journal/paper-ledger.md (${s.ledgerRows} rows)${RESET}`);
  L(`  ${DIM}status: docs/trading/paper-status.md${RESET}`);
  L('');
  if (m.totalTrades < 30) {
    L(`  ${YELLOW}⚠  ${m.verdict}${RESET}`);
    L(`  ${DIM}   Paper trades are a rehearsal of the machinery, not evidence of an edge.${RESET}`);
  }
}

async function cmdPaper(args) {
  const opts = {
    strategy: args.strategy || 'sma-crossover',
    pair: args.pair || 'XRPUSD',
    interval: num(args.interval, 60),
    equity: num(args.equity, 250),
    reset: args.reset === true,
    paperStart: args['paper-start'] || null,
    deposit: args.deposit ? num(args.deposit, 0) : null,
    depositNote: args.note || '',
    refresh: args.refresh !== false,
    makerFee: num(args.makerFee, 0.004),
    takerFee: num(args.takerFee, 0.008),
    slippageBps: num(args.slippage, 5),
    riskPct: num(args.risk, 0.5),
    maxNotionalPct: num(args.maxNotional, 25),
    minTrades: num(args.minTrades, 30),
  };

  if (args.loop) {
    const every = Math.max(1, num(args.loop, 60)) * 60 * 1000;
    console.log(`  ${DIM}paper loop: every ${num(args.loop, 60)} min — Ctrl-C to stop${RESET}`);
    for (;;) {
      try {
        const status = await runPaperCycle(opts);
        printPaperReport(status);
      } catch (err) {
        console.error(`  ${RED}cycle error:${RESET} ${err.message}`);
      }
      await new Promise((r) => setTimeout(r, every));
    }
  }

  const status = await runPaperCycle(opts);
  printPaperReport(status);
}

async function cmdData(args) {
  const { bars, source } = await loadBars(args);
  console.log(`  source    ${source}`);
  console.log(`  bars      ${bars.length}`);
  if (bars.length) {
    console.log(`  from      ${new Date(bars[0].time).toISOString()}`);
    console.log(`  to        ${new Date(bars[bars.length - 1].time).toISOString()}`);
    console.log(`  last      ${bars[bars.length - 1].close}`);
  }
  console.log('');
}

async function cmdTicker(args) {
  const t = await fetchTicker({ pair: args.pair || 'XRPUSD' });
  console.log(`  ${BOLD}${args.pair || 'XRPUSD'}${RESET}`);
  console.log(line('bid', t.bid, `ask       ${t.ask}`));
  console.log(line('last', t.last, `spread    ${t.spreadBps.toFixed(1)} bps`));
  console.log('');
}

function cmdStrategies() {
  console.log('');
  for (const s of listStrategies()) {
    console.log(`  ${BOLD}${s.name}${RESET}`);
    console.log(`    ${s.description}`);
    console.log(`    ${DIM}hypothesis: ${s.hypothesis}${RESET}`);
    console.log(`    ${DIM}params: ${JSON.stringify(s.params)}${RESET}`);
    console.log('');
  }
}

function usage() {
  console.log(`
  ${BOLD}digitraders engine${RESET} — backtesting for the trading desk

  ${BOLD}data${RESET}       --pair XRPUSD --interval 240 [--refresh]
      Fetch OHLC candles from Kraken's public API and cache them.

  ${BOLD}backtest${RESET}   --strategy sma-crossover [--pair XRPUSD] [--interval 240]
               [--equity 250] [--risk 0.5] [--csv path.csv] [--out results.json]
               [--min-trades 30] [--force] [--no-benchmark]
      Run a backtest. Exits 2 when the sample is too small to mean anything.

  ${BOLD}walkforward${RESET} --strategy sma-crossover [--windows 4] [--train-ratio 0.7]
      Rolling in-sample / out-of-sample test. Trust only the stitched OOS number.

  ${BOLD}paper${RESET}      --strategy sma-crossover [--pair XRPUSD] [--interval 60]
               [--equity 250] [--reset] [--loop 60] [--deposit 100 --note "payday"]
      THE PAPER-TRADING CYCLE. Pulls live Kraken candles, runs the strategy
      through the real engine, logs closed paper trades, updates the status file.
      Never touches exchange keys. --loop repeats every N minutes.

  ${BOLD}ticker${RESET}     --pair XRPUSD
      Live bid/ask/spread from Kraken.

  ${BOLD}strategies${RESET}
      List strategies and their hypotheses.

  Common flags: --maker-fee 0.004 --taker-fee 0.008 --slippage 5 --max-notional 25
`);
}

const args = parseArgs(process.argv.slice(2));
const cmd = args._[0] || 'help';

try {
  switch (cmd) {
    case 'backtest': await cmdBacktest(args); break;
    case 'walkforward': await cmdWalkForward(args); break;
    case 'paper': await cmdPaper(args); break;
    case 'data': await cmdData(args); break;
    case 'ticker': await cmdTicker(args); break;
    case 'strategies': cmdStrategies(); break;
    case 'help':
    default: usage(); break;
  }
} catch (err) {
  console.error(`\n  ${RED}error:${RESET} ${err.message}\n`);
  process.exit(1);
}
