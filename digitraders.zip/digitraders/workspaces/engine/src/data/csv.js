import fs from 'node:fs';
import path from 'node:path';

/**
 * CSV loading for historical data.
 *
 * Kraken's public OHLC only gives you 720 candles (2 years daily, 30 days at
 * 4H). For deeper history, download a CSV and point the engine at it.
 *
 * Sources for Kraken OHLC CSVs:
 *   - CryptoDataDownload (free): https://www.cryptodatadownload.com/data/kraken/
 *   - KrakenData (paid): https://www.kraken.com/data
 *   - Any export with timestamp/open/high/low/close/volume columns
 *
 * The parser is deliberately forgiving: it sniffs the header, accepts several
 * timestamp formats, and sorts by time.
 */

const HEADER_ALIASES = {
  time: ['time', 'timestamp', 'date', 'datetime', 'unix', 'open_time', 'time_stamp'],
  open: ['open', 'o'],
  high: ['high', 'h'],
  low: ['low', 'l'],
  close: ['close', 'c', 'adj close', 'close_price'],
  volume: ['volume', 'v', 'vol', 'base volume'],
};

function splitCsvLine(line) {
  const out = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      out.push(cur); cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

function findColumn(header, kind) {
  const aliases = HEADER_ALIASES[kind];
  for (const alias of aliases) {
    const idx = header.findIndex((h) => h.toLowerCase() === alias);
    if (idx !== -1) return idx;
  }
  // fall back to substring match
  for (const alias of aliases) {
    const idx = header.findIndex((h) => h.toLowerCase().includes(alias));
    if (idx !== -1) return idx;
  }
  return -1;
}

function parseTime(raw) {
  const n = Number(raw);
  if (!Number.isNaN(n) && n > 0) {
    // seconds or milliseconds
    return n > 1e12 ? n : n * 1000;
  }
  const d = Date.parse(raw);
  if (Number.isNaN(d)) throw new Error(`unparseable timestamp: ${raw}`);
  return d;
}

/**
 * @param {string} filePath
 * @returns {Array} bars sorted ascending by time
 */
export function loadCsv(filePath) {
  const text = fs.readFileSync(filePath, 'utf8');
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length);
  if (lines.length < 2) throw new Error(`CSV ${filePath} has no data rows`);

  const header = splitCsvLine(lines[0]);
  const idx = {
    time: findColumn(header, 'time'),
    open: findColumn(header, 'open'),
    high: findColumn(header, 'high'),
    low: findColumn(header, 'low'),
    close: findColumn(header, 'close'),
    volume: findColumn(header, 'volume'),
  };
  for (const [k, v] of Object.entries(idx)) {
    if (v === -1) throw new Error(`CSV ${filePath} is missing a "${k}" column (headers: ${header.join(', ')})`);
  }

  const bars = [];
  for (let i = 1; i < lines.length; i++) {
    const cells = splitCsvLine(lines[i]);
    if (cells.length < header.length) continue;
    const open = Number(cells[idx.open]);
    const high = Number(cells[idx.high]);
    const low = Number(cells[idx.low]);
    const close = Number(cells[idx.close]);
    if (![open, high, low, close].every(Number.isFinite)) continue;
    bars.push({
      time: parseTime(cells[idx.time]),
      open, high, low, close,
      volume: idx.volume === -1 ? 0 : Number(cells[idx.volume]) || 0,
    });
  }

  bars.sort((a, b) => a.time - b.time);
  return bars;
}

/** Write bars back out as CSV (same format we accept). */
export function saveCsv(filePath, bars) {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const rows = ['time,open,high,low,close,volume'];
  for (const b of bars) {
    rows.push([Math.floor(b.time / 1000), b.open, b.high, b.low, b.close, b.volume ?? 0].join(','));
  }
  fs.writeFileSync(filePath, rows.join('\n') + '\n');
  return filePath;
}
