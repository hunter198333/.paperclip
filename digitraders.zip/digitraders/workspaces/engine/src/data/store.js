import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchOHLC } from './kraken.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const CACHE_DIR = path.resolve(here, '..', '..', '.cache');

function cachePath(pair, interval) {
  return path.join(CACHE_DIR, `${pair.toUpperCase()}-${interval}.json`);
}

/**
 * Load candles: from cache if it's there and fresh enough, otherwise from
 * Kraken's public API (then cached).
 */
export async function loadCandles({ pair = 'XRPUSD', interval = 240, refresh = false, maxAgeMs = 6 * 60 * 60 * 1000 } = {}) {
  const file = cachePath(pair, interval);

  if (!refresh && fs.existsSync(file)) {
    const age = Date.now() - fs.statSync(file).mtimeMs;
    if (age < maxAgeMs) {
      const cached = JSON.parse(fs.readFileSync(file, 'utf8'));
      return { bars: cached.bars, source: 'cache', fetchedAt: cached.fetchedAt };
    }
  }

  const bars = await fetchOHLC({ pair, interval });
  fs.mkdirSync(CACHE_DIR, { recursive: true });
  fs.writeFileSync(file, JSON.stringify({ pair, interval, fetchedAt: new Date().toISOString(), bars }));
  return { bars, source: 'kraken', fetchedAt: new Date().toISOString() };
}

/** Drop cached candles. */
export function clearCache() {
  if (fs.existsSync(CACHE_DIR)) fs.rmSync(CACHE_DIR, { recursive: true, force: true });
  return CACHE_DIR;
}

export { CACHE_DIR };
