/**
 * Kraken public market data. No API key required.
 *
 * Kraken returns legacy asset names (`XXRPZUSD` for XRP/USD, `XXBTZUSD` for
 * BTC/USD) — that mapping lives here so it never leaks into strategy code.
 */

const BASE = 'https://api.kraken.com/0/public';

/**
 * Kraken's legacy asset codes. These are the codes Kraken uses internally and
 * in the result key of API responses — `XXRPZUSD` for XRP/USD.
 *
 * The engine never *depends* on this map: `fetchOHLC` discovers the key from
 * the response. This exists so a human reading a log or a JSON dump can map
 * `XXRPZUSD` back to `XRPUSD`.
 */
const LEGACY = {
  BTC: 'XXBT', XBT: 'XXBT', ETH: 'XETH', XRP: 'XXRP', LTC: 'XLTC', ZEC: 'XZEC',
  DOGE: 'XDG', BCH: 'XBC', XMR: 'XXMR', ADA: 'ADA', DOT: 'DOT', SOL: 'SOL',
  MATIC: 'MATIC', LINK: 'LINK', TRX: 'TRX', ATOM: 'ATOM', AVAX: 'AVAX',
  USD: 'ZUSD', EUR: 'ZEUR', GBP: 'ZGBP', CAD: 'ZCAD', AUD: 'ZAUD', JPY: 'ZJPY',
  USDT: 'USDT', USDC: 'USDC', DAI: 'DAI', DOTUSD: 'DOTUSD',
};

/** Quote assets we know how to split a pair on, longest first. */
const QUOTES = ['USDT', 'USDC', 'USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY', 'BTC', 'ETH'];

/** Split a pair like `XRPUSD` into its base and quote assets. */
export function splitPair(pair) {
  const p = pair.toUpperCase();
  for (const q of QUOTES) {
    if (p.length > q.length && p.endsWith(q)) {
      return { base: p.slice(0, -q.length), quote: q };
    }
  }
  return { base: p, quote: '' };
}

/** Kraken's result key for a pair, e.g. XRPUSD -> XXRPZUSD. */
export function krakenResultKey(pair) {
  const { base, quote } = splitPair(pair);
  const b = LEGACY[base] ?? base;
  const q = quote ? (LEGACY[quote] ?? quote) : '';
  return b + q;
}

/**
 * Fetch OHLC candles.
 * Kraken caps this at 720 candles per call (plus the in-progress bar).
 *
 * @param {Object} opts
 *   pair     e.g. 'XRPUSD'
 *   interval minutes: 1 | 5 | 15 | 30 | 60 | 240 | 1440 | 10080 | 21600
 */
export async function fetchOHLC({ pair = 'XRPUSD', interval = 240, since } = {}) {
  const url = new URL(`${BASE}/OHLC`);
  url.searchParams.set('pair', pair);
  url.searchParams.set('interval', String(interval));
  if (since) url.searchParams.set('since', String(since));

  const res = await fetch(url, { headers: { 'User-Agent': 'digitraders-engine/0.1' } });
  if (!res.ok) throw new Error(`Kraken OHLC request failed: HTTP ${res.status}`);
  const json = await res.json();
  if (json.error && json.error.length) {
    throw new Error(`Kraken API error: ${json.error.join(', ')}`);
  }

  const key = Object.keys(json.result).find((k) => k !== 'last');
  if (!key) throw new Error(`no data returned for ${pair}`);

  const rows = json.result[key];
  const bars = rows.map((r) => ({
    time: r[0] * 1000,            // ms
    open: Number(r[1]),
    high: Number(r[2]),
    low: Number(r[3]),
    close: Number(r[4]),
    vwap: Number(r[5]),
    volume: Number(r[6]),
    count: Number(r[7]),
  }));

  // Drop the in-progress bar (Kraken's last row is the live candle)
  const last = json.result.last * 1000;
  return bars.filter((b) => b.time < last);
}

/** Best bid/ask. */
export async function fetchTicker({ pair = 'XRPUSD' } = {}) {
  const url = new URL(`${BASE}/Ticker`);
  url.searchParams.set('pair', pair);
  const res = await fetch(url, { headers: { 'User-Agent': 'digitraders-engine/0.1' } });
  const json = await res.json();
  if (json.error && json.error.length) throw new Error(`Kraken API error: ${json.error.join(', ')}`);
  const key = Object.keys(json.result).find((k) => k !== 'last');
  const t = json.result[key];
  return {
    bid: Number(t.b[0]),
    ask: Number(t.a[0]),
    last: Number(t.c[0]),
    spreadBps: ((Number(t.a[0]) - Number(t.b[0])) / Number(t.c[0])) * 10000,
    volume24h: Number(t.v[1] ?? 0),
  };
}

/** Top of book, up to `depth` levels. */
export async function fetchOrderBook({ pair = 'XRPUSD', depth = 10 } = {}) {
  const url = new URL(`${BASE}/Depth`);
  url.searchParams.set('pair', pair);
  url.searchParams.set('count', String(depth));
  const res = await fetch(url, { headers: { 'User-Agent': 'digitraders-engine/0.1' } });
  const json = await res.json();
  if (json.error && json.error.length) throw new Error(`Kraken API error: ${json.error.join(', ')}`);
  const key = Object.keys(json.result).find((k) => k !== 'last');
  const [asks, bids] = json.result[key];
  return {
    asks: asks.map(([p, q]) => ({ price: Number(p), qty: Number(q) })),
    bids: bids.map(([p, q]) => ({ price: Number(p), qty: Number(q) })),
  };
}

/** Server time, useful to check clock skew. */
export async function fetchServerTime() {
  const res = await fetch(`${BASE}/Time`, { headers: { 'User-Agent': 'digitraders-engine/0.1' } });
  const json = await res.json();
  return new Date(json.result.unixtime * 1000);
}
