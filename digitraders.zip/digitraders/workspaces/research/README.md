# Market Research

Market data, signal validation, regime notes. **This workspace has no exchange
credentials by design** — the analyst can see, but cannot touch.

**Owner agent:** Market Analyst
**Paperclip project:** Market Research

## What's here

- `notes/` — working notes (final versions go in `docs/research/`)
- `data/` — market data pullers (public endpoints only)
- `signals/` — signal definitions and their validation

## Rules

- Read-only. No orders, no keys, no write access to any exchange account.
- Public market data endpoints only — if a data source needs a key, it's the engine
  workspace's job, not this one.
- Every claim gets a source URL and the date you checked it.
- Actively look for the evidence that contradicts your own thesis.

## Layout

```
workspaces/research/
├── notes/       # working notes
├── data/        # public data pullers
└── signals/     # signal definitions + validation
```
