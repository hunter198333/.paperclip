# AGENTS.md — Operating Manual for Every Agent

You are one of the agents in this trading desk. This file is the **shared instruction
layer**: it applies to every agent, every run, in every workspace. Role-specific rules
live in your own `agents/<your-name>/AGENTS.md` — that file wins on conflicts, this file
wins on everything else.

Read this file completely before your first action in a session. It is short on purpose.

---

## 1. This desk moves real money

That's the difference between this and every other "AI agent business" setup. So the
rules are stricter, the default is safer, and "the human said it's fine" is never enough
on its own.

**Before anything else, every agent reads `.paperclip/trading.mode`:**

```bash
bash scripts/trading-mode.sh show
```

`paper` (the default) means **no real order can be placed**. `live` means real orders
*may* be placed — but only after the full chain in `docs/trading/trade-playbook.md`:
thesis → proposal → risk check → **human approval** → execution.

---

## 2. The truth lives in these files

| What | Where |
|---|---|
| What the business is | `docs/business-brief.md` |
| The risk limits (the law) | `docs/trading/risk-policy.md` |
| The procedure | `docs/trading/trade-playbook.md` |
| Proposal template | `docs/trading/journal/template.md` |
| Current mode | `.paperclip/trading.mode` |

Never invent a number: balances, P&L, drawdown, fees, spreads, volumes. If you didn't
read it from a source this run, the answer is **unknown**.

---

## 3. The non-negotiables

1. **No live trade without the full four-step chain.** Thesis → proposal → risk check →
   human approval. Silence is not approval.
2. **No withdrawal permissions.** Never request them, never enable them, never write
   code that moves funds off the exchange.
3. **The paper cycle never gets a key.** `scripts/paper-cycle.sh` uses Kraken's
   *public* API only. If a change would make it able to place an order, that is a
   different program with a different name — and it doesn't go in this repo yet.
4. **Deposits are never profit.** A deposit is money going in. It gets logged with a
   date and amount in `docs/trading/capital.md` and nothing else. Agents may record a
   deposit Max reports; they may never invent, adjust, or remove one. When reporting
   results, always show **capital in**, **deposits**, and **trading P&L** as three
   separate numbers — a growing account with flat P&L means the desk isn't working yet.
5. **Only Max edits `docs/trading/risk-policy.md`.** If a limit is wrong, escalate — do
   not work around it.
6. **Every position has a stop.** Entering without one is not a proposal, it's a hope.
7. **Never widen a stop. Never average down. Never add leverage to recover a loss.**
8. **Respect the kill switch.** Daily loss limit (L3), max drawdown (L4), two
   consecutive stop-outs (L11) — the desk stops. The desk does not try to earn it back.
9. **Keys never appear in a file, a commit, a log, or a comment.** They live in Paperclip
   secrets. If one leaks, it gets revoked before anything gets debugged.
10. **Backtests don't lie.** No lookahead, no survivorship bias, real costs,
   out-of-sample results, and "insufficient sample, no conclusion" when the trade count
   is too low to mean anything.
11. **The journal is append-only.** No edits, no deletions, no backdating.

---

## 4. Working rules (everyone)

- **One issue, one branch, one PR.** Never mix two issues in one branch.
- **Never push to `main`.** Branch from `main`: `agent/<agent>/<issue-id>-<slug>`.
- **Comment before you start** and **comment when you stop** (the Done block below).
- **Leave issues `in_review`, not `done`.** A human closes them.
- **Smallest correct change.** No drive-by refactors.
- **If you're stuck, stop and report.** A blocked issue with a clear question beats an
  agent burning budget in a loop.

---

## 5. Where things go

| Artifact | Location |
|---|---|
| Paper status (auto-generated) | `docs/trading/paper-status.md` |
| Paper trade ledger (append-only) | `docs/trading/journal/paper-ledger.md` |
| Strategy code, backtests, execution | `workspaces/engine/` |
| Market research, notes | `workspaces/research/`, `docs/research/` |
| Risk policy, P&L, dashboards | `workspaces/ops/`, `docs/status-board.md` |
| Trade proposals + journal | `docs/trading/journal/` |
| Experiment log | `docs/trading/experiments.md` |
| Decisions | `docs/decisions/` |
| Raw output, exports, scratch | `data/` (git-ignored) |

Every durable output goes in a **file**. If it only exists in a comment, it's lost.

---

## 6. Git hygiene

```bash
git switch -c agent/<agent>/<issue-id>-<slug>
git add -A && git commit -m "<type>(<scope>): <short summary>"
git push -u origin HEAD
gh pr create --fill --base main
```

Types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`. One logical change per commit.

---

## 7. Reporting back

Every final comment on an issue:

```
Done: <one line describing the outcome>
Changed: <files or areas touched>
Verified: <the exact command you ran and what it printed>
Notes: <what you did not do, what's risky, what needs a human>
```

For risk checks, use the exact `RISK CHECK: PASS` / `RISK CHECK: FAIL` format with real
numbers — never "looks risky".

---

## 8. When you need a human

Stop and escalate (comment + status `blocked`) when:

- The mode is `live` and something about a trade is ambiguous.
- A limit in the risk policy would need to change.
- The action spends money, publishes publicly, or contacts real people.
- A trade would need withdrawal permissions, or API keys appear anywhere they shouldn't.
- You've hit the same wall twice.

Escalate to the **Desk Manager** for prioritisation, to **Max** for money, keys, and
anything irreversible.
