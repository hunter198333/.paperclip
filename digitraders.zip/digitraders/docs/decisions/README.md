# Decisions

One file per decision, named `YYYY-MM-DD-short-slug.md`.

The point: three months from now, an agent (or you) can answer *why did we do it this way*
without re-litigating it. The CEO agent maintains this log; other agents read it before
making decisions that were already settled.

## Template

```markdown
# <Decision in one sentence>

**Date:** YYYY-MM-DD
**Decided by:** <agent / human>
**Status:** proposed | accepted | superseded by <file>

## Context
<what forced the decision — the facts, not the story>

## Decision
<what we are doing, in the active voice>

## Alternatives considered
- <option> — <why not>

## Consequences
- <what this makes easy>
- <what this makes hard>
- <what we now have to watch>

## Revisit when
<the trigger that would make us reopen this>
```
