# Research

Notes from the **Researcher** agent.

One file per question: `YYYY-MM-DD-question-slug.md`.

Every factual claim carries a source URL and the date it was checked. Numbers without
sources don't belong here — they belong in "open questions".
