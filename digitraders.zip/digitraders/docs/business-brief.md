# Business Brief — Digitraders

> **Agents: read this before every run.** Facts marked `[TODO: Max]` are unknown — don't
> invent them, ask or flag it. This is a **live-money** desk: when in doubt, do less.

**Owner:** Max (solo crypto trader)
**Company:** Digitraders
**Issue prefix:** DGT → issues read `DGT-1`, `DGT-2`, …
**Exchange:** Kraken (Pro spot)
**Started:** 2026-10-25

---

## 1. What this is

A **home trading center where AI agents do the work.** Max sets the strategy and the risk
limits; agents research, backtest, size positions, check risk, and prepare execution;
Max approves every live trade.

**Digitraders is also a learning project.** Max is using Paperclip (alongside Monday.com,
ClickUp and Make) to learn how AI agents actually run a business end to end — the kind
of thing you can't learn from a tutorial.

### The two goals, in order

1. **Don't lose money.** A desk that blows up teaches you expensive lessons.
2. **Learn the craft.** Ship a rig that runs without being babysat.

A profitable strategy that arrives in month three is a bonus. The rig working end to end
is the actual deliverable right now — and at this capital level it genuinely is the
better investment.

---

## 2. The trader

- **Exchange:** Kraken (Pro spot) — no futures, no margin, no leverage
- **Capital:** **$250.00** starting balance, **+$100 every payday** — see §2.1
- **Fee tier:** Tier 1 (30-day volume $0+) → **0.40% maker / 0.80% taker**
- **Time available:** `[TODO: Max]` — how much time per day to review agent output
- **Current approach:** `[TODO: Max]` — what's being traded today, and what makes it
  work (or not)
- **Existing holdings:** ~250 XRP — note that *selling* XRP to trade costs the same
  0.40–0.80% as any other round trip

### 2.1 The capital plan

| | |
|---|---|
| Starting balance | **$250.00** |
| Weekly contribution | **+$100.00 per payday** |
| Projected balance by Christmas (≈7 deposits) | **~$950** |
| Trading P&L so far | see `docs/trading/paper-status.md` |

**The account reaches ~$950 by Christmas because of deposits, not trading.** That's the
plan and it's a good one. Trading P&L is the bonus on top, and it's tracked separately so
nobody ever mistakes a paycheck for a profit.

Every deposit gets logged with a date and amount in `docs/trading/capital.md`. Every
limit in the risk policy is a percentage, so the limits scale with the balance as it
grows — $0.5% risk is $1.25 at $250 and $4.75 at $950.

### Capital reality — read this before sizing anything

At $250, a full-account round trip costs **$2 (maker) or $4 (taker) in fees alone.**
That's 0.8%–1.6% of the account burned before the trade has any chance of working.

**Money needed for living expenses is not trading capital.** Bills, the car, tires, the
alignment — none of that is available to the desk, and a trade that would eat into it
doesn't happen. This isn't a rule for later when there's more money; it's the reason
the desk defaults to `paper` mode and takes 1% risk per trade at most.

---

## 3. What the agents do

| Agent | Owns | Works in | Can it touch money? |
|---|---|---|---|
| **Desk Manager** | priorities, proposals, assignment | business root | No — proposes only |
| **Quant Developer** | strategies, backtests, execution | `workspaces/engine` | Only after approval |
| **Market Analyst** | market data, research, signal validation | `workspaces/research` | **No trading key** |
| **Risk and Ops** | risk checks, P&L, journal, kill switch | `workspaces/ops` | No — holds the veto |

**The chain:** thesis → proposal → risk check → human approval → execution.
Full procedure: `docs/trading/trade-playbook.md`.

---

## 4. Rules that are not negotiable

- **Paper first.** The desk starts in `paper` mode and stays there until backtest and
  paper-trade evidence justify otherwise. Only Max flips the switch:
  `bash scripts/trading-mode.sh live`.
- **No withdrawal permissions.** Not ever, on any key, for any reason.
- **Maker orders only.** Limit/post-only. A market order doubles the fee drag.
- **Limits live in `docs/trading/risk-policy.md`**, and only Max edits that file.
- **Every trade is written down** in `docs/trading/journal/` before it happens.
- **Agents don't get to be clever with risk.** No averaging down, no widening stops, no
  "one more trade to break even."

---

## 5. The first 30 days

| Week | Milestone | Done when |
|---|---|---|
| 1 | Desk wired up, brief filled in, no live anything | `bash scripts/doctor.sh` is green; mode is `paper` |
| 2 | One strategy backtested with an out-of-sample result | Numbers posted in `docs/trading/experiments.md` |
| 3 | Same strategy run in paper mode against live market data | ≥ 20 paper trades logged in the journal |
| 4 | First *proposal* written, risk-checked, and approved for paper | A complete journal entry exists |

**Realistic target:** no live capital moves in month one. The month-one win is a desk
that runs without you babysitting it, and a strategy whose edge you've actually measured
instead of assumed.

---

## 6. Budget

- **Monthly spend ceiling:** `[TODO: Max]` — agent runs, plus Kraken data (public
  endpoints are free; paid data isn't needed yet)
- **Cost per agent run:** track it in `docs/status-board.md` under Costs
- **Hard rule:** the Risk agent stops the desk before the budget is gone

---

## 7. Tooling

| Tool | Role |
|---|---|
| **Paperclip** | the agent runtime — company, goals, projects, issues, agents |
| **Acode** | editing the workspace on the phone |
| **Termux** | running the desk on the phone |
| **Monday / ClickUp** | external tracking (optional; Paperclip is the source of truth) |
| **Make** | glue for non-agent automations (optional) |
| **pnpm** | package management across the workspaces |
| **GitHub** | code, branches, PRs for the engine |
| **Kraken** | the exchange — spot only, API-driven |

---

## 8. Where things live

| Artifact | Location |
|---|---|
| Strategy code, backtests | `workspaces/engine/` |
| Market research, notes | `workspaces/research/`, `docs/research/` |
| Risk policy | `docs/trading/risk-policy.md` |
| Position sizing calculator | `scripts/position-size.sh` |
| Kraken key setup | `docs/playbooks/kraken-setup.md` |
| Trade proposals + journal | `docs/trading/journal/` |
| Experiments log | `docs/trading/experiments.md` |
| Daily dashboard | `docs/status-board.md` |
| Decisions | `docs/decisions/` |

---

## 9. Open questions for Max

- `[TODO: Max]` Which strategy is being researched first?
- `[TODO: Max]` Accept the default risk limits (0.5% per trade, 2% daily stop, no
      leverage), or change them?
- `[TODO: Max]` Does the desk run on the PC (recommended) or the phone?
- `[TODO: Max]` Which agent CLI runs on the host (codex / claude / opencode)?
- `[TODO: Max]` How much time per day can you spend reviewing agent output?
- `[TODO: Max]` Spot only, or is Kraken Futures eventually in scope?
