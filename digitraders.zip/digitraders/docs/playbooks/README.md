# Playbooks

Repeatable procedures, written down so an agent can execute them without asking.

A playbook is a list of exact steps with exact commands. If a step needs a human decision,
mark it clearly with `[HUMAN]` and say what they're approving.

## Naming

`YYYY-MM-DD-procedure-name.md` — one playbook per file.

## Template

```markdown
# <Procedure name>

**Owner:** <agent>
**Last verified:** YYYY-MM-DD
**Trigger:** <what starts this procedure — a command, an issue label, a schedule>

## Preconditions
- [ ] <what must be true before starting>

## Steps
1. `<exact command or action>`
2. `<exact command or action>`
   - `[HUMAN]` <what a human must approve, and what the agent does while waiting>

## Verify
- `<command>` → <expected output>

## If it breaks
- **Symptom:** <what you see>
- **Fix:** <the recovery steps>
```
