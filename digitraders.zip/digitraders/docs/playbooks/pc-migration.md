# Moving the Desk to a PC

The phone was a fine place to *design* the desk. A PC is a much better place to *run*
it. Here's the move.

---

## What you gain by moving

| | Phone (Termux) | PC |
|---|---|---|
| Paperclip's embedded Postgres | slow, sometimes won't boot | works properly |
| Long-running processes | Android kills them (signal 9) | fine, with a systemd timer |
| Kraken key IP allowlist | impossible — mobile IP changes | possible, stable home IP |
| Browser access to the board | works | works, much better |
| Crank (his big rig) | not happening | not happening |

The **IP allowlist** is the big one. A Kraken key locked to your home IP is materially
safer than one unlocked — and that's a key you can create on the PC and let the desk
use from there.

---

## What to move

Almost everything is plain text and syncs perfectly:

- `docs/` — brief, risk policy, experiments, **paper ledger**, **capital ledger**, journal
- `.paperclip/` — company config, agent configs, scripts
- `agents/` — the four instruction files
- `workspaces/engine/src` + `tests` — the engine code

Two things don't need to move:

- `workspaces/engine/.cache/` — cached candles. Regenerated on first run.
- `workspaces/engine/.paper/state.json` — machine state. **Do move this** if you want the
  paper record to continue rather than restart (see Option A).

---

## Option A — Git (recommended, keeps them in sync)

The desk is already a git-shaped project. Use GitHub as the courier.

### On the phone

```bash
cd ~/storage/shared/digitraders

git init -b main
git add -A
git commit -m "chore: digitraders desk scaffold"

# create a PRIVATE repo on GitHub, then:
git remote add origin git@github.com:<you>/digitraders.git
git push -u origin main
```

If the phone can't do SSH keys, use HTTPS with a personal access token.

### On the PC

```bash
git clone git@github.com:<you>/digitraders.git
cd digitraders

# node 24 first — https://nodejs.org or nvm
node -v

bash scripts/doctor.sh
bash .paperclip/bootstrap.sh
```

### Keeping them in sync afterwards

The phone is where you *talk* to the desk. The PC is where it *runs*. So:

- **PC** = run the paper cycle, Paperclip, the agents. Pull before each cycle.
- **Phone** = read the status, talk to the agents. Push your notes.

```bash
# on the PC, before a cycle
git pull

# after a cycle
git add -A && git commit -m "chore: paper cycle" && git push
```

A small script does this for you — see `scripts/sync.sh` below.

### ⚠️ Two things to check before you push

1. **Never commit a key.** `.gitignore` already excludes `.paperclip/paperclip.env`,
   `.env*` and `data/`. Run `git status` before committing and look.
2. **The paper ledger must not conflict.** If the phone and PC both write to
   `docs/trading/journal/paper-ledger.md`, git will conflict. **Pick one machine to run
   the cycle** (the PC) and let the other just read.

---

## Option B — Zip over USB (one-off, no GitHub)

If you'd rather not push anything to GitHub yet:

### On the phone

```bash
cd ~/storage/shared
tar czf digitraders-backup.tar.gz digitraders
```

Or from Acode: long-press the `digitraders` folder → compress/share → send it to
yourself (email, Telegram, Drive, USB).

### On the PC

```bash
tar xzf digitraders-backup.tar.gz
cd digitraders
node -v
bash scripts/doctor.sh
```

One-off only. After this, switch to Option A or you'll lose work.

---

## After the move: the PC setup

**One command does it all:**

```bash
bash pc-setup.sh
```

It checks Node 24, installs the Paperclip CLI, checks your git identity, installs the
timer, registers the agents, runs the first paper cycle, and prints a summary.
Safe to re-run.

If you'd rather do it by hand, the steps are below.

### Run the cycle on a timer (Linux, systemd)

Create `~/.config/systemd/user/digitraders-paper.service`:

```ini
[Unit]
Description=Digitraders paper trading cycle

[Service]
Type=oneshot
WorkingDirectory=%h/digitraders
ExecStart=%h/digitraders/scripts/paper-cycle.sh --strategy sma-crossover --pair XRPUSD --interval 60
```

And `~/.config/systemd/user/digitraders-paper.timer`:

```ini
[Unit]
Description=Run the Digitraders paper cycle hourly

[Timer]
OnBootSec=5min
OnUnitActiveSec=1h
Persistent=true

[Install]
WantedBy=timers.target
```

Then:

```bash
systemctl --user daemon-reload
systemctl --user enable --now digitraders-paper.timer
systemctl --user list-timers | grep digitraders
```

### Or just cron

```bash
crontab -e
```

```
0 * * * * /home/you/digitraders/scripts/paper-cycle.sh --strategy sma-crossover --pair XRPUSD --interval 60 >> /home/you/digitraders/data/paper-cycle.log 2>&1
```

> The cycle is deterministic — it costs **nothing** to run it on a timer. Only the
> *agents'* wakeups cost money. That's why the script runs on cron and the agents wake
> less often, to interpret what it produced.

---

## When you're ready for a key

Now is the right time, because you can lock it to your IP:

1. Kraken → Settings → API → Add key
2. **Query Funds** ✅, **Query Open Orders & Trades** ✅, **Create & Modify Orders** ✅,
   **Cancel/Close Orders** ✅
3. **Withdraw Funds** ❌ **Deposit Funds** ❌ — leave them off, permanently
4. **IP allowlist**: add your PC's public IP (`curl ifconfig.me`)
5. Store it: `paperclipai secrets create --company-id <id> --name kraken-api-key --value-env KRAKEN_API_KEY`

Full details: `docs/playbooks/kraken-setup.md`.

And still: **paper first.** The key is the last step, not the first.
