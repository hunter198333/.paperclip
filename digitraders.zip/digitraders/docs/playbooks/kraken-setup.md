# Kraken Setup — safe key creation

How to connect Kraken to the desk without handing it the ability to empty the account.

Kraken's permission model is genuinely good here: you pick exactly what each key can do,
so "trading but not withdrawing" is a checkbox, not a hope.

---

## 1. Create the keys (Settings → API → Add key)

Create **two** keys with different permissions. The blast radius of each should be obvious
just by looking at its name.

### Key A — `digitraders-engine` (the only key that can trade)

| Kraken permission | Enable | Why |
|---|---|---|
| Query Funds | ✅ | read balances for sizing |
| Query Open Orders & Trades | ✅ | confirm order state, detect fills |
| Create & Modify Orders | ✅ | place orders |
| Cancel/Close Orders | ✅ | manage positions and exits |
| **Deposit Funds** | ❌ **NO** | not needed, ever |
| **Withdraw Funds** | ❌ **NO** | **never. this is the one that matters.** |
| Get WebSocket Token | only if you use private WS | token is short-lived (15 min) |
| Query Ledger / Export Data | optional | reconciliation and reporting |

- [ ] **IP allowlist** the key if the execution host has a stable IP. A phone on mobile
      data doesn't — which is a strong argument for running execution from a fixed host
      (a small VPS) and keeping the phone as the operator's console.
- [ ] The key has **no withdrawal or deposit permission**. Verify it on screen before you
      save it. Take a screenshot for `docs/decisions/`.

### Key B — `digitraders-readonly` (research workspace)

| Kraken permission | Enable |
|---|---|
| Query Funds | ✅ |
| Query Open Orders & Trades | ✅ |
| everything else | ❌ |

Give this to the **research** workspace only. It can look at the account and cannot touch
it. Ideally give the research workspace **no key at all** and use Kraken's public market
data endpoints — but this key exists for balance/margin checks.

### Note on subaccounts

Kraken **spot** subaccounts are institutional-only. **Kraken Futures (derivatives)**
subaccounts are open to any eligible client via a support ticket. If you ever want a
strategy isolated from the main balance, that's the route — but it's a Derivative
account with its own keys, and perps are out of scope at this capital level.

---

## 2. Store them in Paperclip secrets (never in a file)

```bash
export KRAKEN_API_KEY='...'
export KRAKEN_API_SECRET='...'

npx paperclipai secrets create --company-id <company-id> \
  --name kraken-api-key --value-env KRAKEN_API_KEY

npx paperclipai secrets create --company-id <company-id> \
  --name kraken-api-secret --value-env KRAKEN_API_SECRET
```

`--value-env` reads the value from the environment variable, so the plaintext never
lands in your shell history or the process argument list.

```bash
npx paperclipai secrets list --company-id <company-id>     # metadata only
npx paperclipai secrets doctor --company-id <company-id>
```

---

## 3. Wire it to the right agent

Only the **Quant Developer** agent's engine workspace gets `kraken-api-key`. The Market
Analyst workspace gets `kraken-api-key-readonly` (or nothing). The Risk and Ops agent
gets the read-only key so it can reconcile against Kraken — it can see, not touch.

Via the project env binding:

```bash
npx paperclipai project update <project-id> \
  --env-json '{"KRAKEN_API_KEY":{"kind":"secret","secretName":"kraken-api-key"}}'
```

---

## 4. Verify the guardrails (before any live mode)

- [ ] `bash scripts/trading-mode.sh show` prints `paper`
- [ ] With mode `paper`, the engine **cannot** place a live order (there's a test)
- [ ] Key A shows **no** `withdraw-funds` permission:
      `npx paperclipai ... ` isn't the way to check — verify in Kraken's UI, or call
      Kraken's `GetApiKeyInfo` endpoint and read the `permissions` array
- [ ] The research workspace has no trading key
- [ ] `grep -r "KRAKEN_API" workspaces/ --include=*.ts --include=*.js` finds only
      `process.env` reads
- [ ] `bash scripts/position-size.sh --equity 250 --entry <p> --stop <p>` runs clean

---

## 5. Kraken API facts worth knowing

| Thing | Detail |
|---|---|
| REST base | `https://api.kraken.com` |
| WebSocket | `ws.kraken.com` (v2 API), `ws.kraken.com/v1` (older) |
| Auth | `API-Key` + `API-Sign` headers, HMAC-SHA512 over nonce+path+SHA256(body) |
| Nonce | must be strictly increasing, per key |
| Rate limits | REST counter-based (max counter 20); WS has its own message caps |
| Private WS | needs `Get WebSocket Token`; the token lives 15 minutes |
| Fees (Tier 1) | 0.40% maker / 0.80% taker on spot |
| Min order size | varies per pair — check before proposing |
| Min trade fee | a minimum amount per pair, which bites on tiny trades |

Kraken's REST API returns **legacy asset/pair names** (e.g. `XXBT` for XBT, `XBTUSD`).
Pair and asset naming normalisation is a real source of bugs — build a mapping table
early and unit-test it.

---

## 6. Rotation and revocation

- **Rotate every 90 days**, and immediately if a key appears in a log, a commit, a
  screenshot, or a chat.
- **Revoke first, debug second.**
- Keep a list of every key you've created, its permissions, and where it's used. If you
  can't name where a key is, revoke it.

---

## 7. The paperwork

Write a decision note in `docs/decisions/` when you set this up: which keys exist, their
exact permission lists, which agent/workspace each is bound to, whether an IP allowlist
is on, and the rotation date.
