# Paper Trading — the daily cycle

How the desk rehearses before it ever touches real money.

**Paper trading proves the machinery works. It does not prove the strategy has an
edge.** Those are different claims and the engine keeps them separate.

---

## What one cycle does

```bash
bash scripts/paper-cycle.sh
```

1. **Pulls the latest candles** from Kraken's *public* API — no key, no account
   access, no orders. (`https://api.kraken.com/0/public/OHLC`)
2. **Runs the strategy** through the same engine that would place a real order:
   same sizing, same fees, same slippage, same next-bar fills.
3. **Keeps only what happened since the paper record began** — the record starts
   fresh, with no inherited history.
4. **Logs closed paper trades** to `docs/trading/journal/paper-ledger.md`
   (append-only, never edited).
5. **Rewrites `docs/trading/paper-status.md`** with equity, P&L, edge vs the
   benchmark, fees, drawdown, and exposure.

---

## What it writes

| File | Written by | Editable? |
|---|---|---|
| `docs/trading/paper-status.md` | the cycle (auto) | No — overwritten each run |
| `docs/trading/journal/paper-ledger.md` | the cycle (append) | No — append only |
| `.paper/state.json` (engine dir) | the cycle (auto) | No — machine state |
| `docs/status-board.md` | **Risk and Ops agent** | Yes — the human-facing board |

The board is the agent's job. The paper status file is the machine's job. They don't
overwrite each other, and the agent should **read** the paper status and **summarise**
it on the board.

---

## Running it on a schedule

**Option A — a loop in its own terminal:**

```bash
bash scripts/paper-cycle.sh --loop 60      # every 60 minutes
```

Keep that terminal alive. On Android, don't let it go to the background — the phantom
process killer will end it. A `tmux`/`screen` session is worth installing if you're
going to leave it running.

**Option B — let the desk drive it:**

The **Quant Developer** agent runs the cycle as part of its heartbeat, and the **Risk
and Ops** agent reports the result. That's the version that scales — you stop being
the scheduler.

**Option C — a cron job on a server** running the same script, if you move Paperclip
to a VPS.

---

## Reading the output

```
equity            $244.77         benchmark   $244.77
net p&l           -$5.23          net %       -2.09%
edge              +$15.70         vs buy&hold
trades            1               win rate    0.00%
profit factor     0.00            max DD      2.94%
fees              $0.71           exposure    99.51%
```

- **Equity** — where the paper account is.
- **Benchmark** — the same account doing nothing but holding. Same notional cap, same
  fees. A like-for-like comparison.
- **Edge** — the only number that matters. If it's negative, the strategy is worse than
  doing nothing, and you should stop running it.
- **Fees** — at $250 these are not a rounding error. Watch this column.

---

## Rules for the paper phase

1. **Paper until the evidence says otherwise.** A strategy needs: an out-of-sample
   result, ≥30 trades (policy L12), and a positive edge after fees.
2. **One strategy at a time.** Two strategies on one paper record is two records.
   Use `--reset` when you switch, and say so in the experiment log.
3. **Never edit the ledger.** It's the record. Corrections are new rows.
4. **Log every cycle in `docs/trading/experiments.md`** — the hypothesis, the change,
   the result, including the failures.
5. **A paper trade is not a profit.** It's a rehearsal. Don't let a good paper week
   talk you into live mode — the approval chain still applies, and the risk policy
   still says what it says.
6. **The paper cycle never gets a key.** If a future version needs one to place
   orders, that's a different program with a different name, and it doesn't go in
   this repo yet.

---

## When paper trading has done its job

Move to live only when **all** of these are true:

- [ ] ≥30 paper trades, logged
- [ ] Positive edge vs buy-and-hold **after fees**
- [ ] Out-of-sample / walk-forward result agrees with in-sample
- [ ] Max drawdown inside the policy limit (L4)
- [ ] The risk policy's limits are set to your real numbers
- [ ] The Kraken key is created with **no withdrawal permission**
- [ ] You can watch the desk run for a week without intervening

Then: `bash scripts/trading-mode.sh live` (it asks you to type the confirmation), and
every trade still goes through the four-step chain.
