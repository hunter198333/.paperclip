# Experiment Log

Every strategy experiment, in order, including the failures. **Failures are the point** —
if this file only has wins, you're not recording experiments, you're recording marketing.

One row per experiment. Append only.

| Date | Hypothesis | Change | In-sample | Out-of-sample | Trades | Result | Notes |
|---|---|---|---|---|---|---|---|
| 2026-10-26 | XRP rises over this period | none — benchmark, all-in, 4h | +5.39% | n/a | 1 | reference | 719 bars, 2026-06-29→2026-10-26. Max DD 7.55%. Fees $0.86. **This is the bar.** |
| 2026-10-26 | Multi-hour trends persist, SMA cross captures part of the move | 20/100 SMA + ATR stop, 4h | +0.04% | n/a | 5 | **discard** | Fees were **2684% of net profit**. Exposure 1.67%. Never beat the benchmark. |
| 2026-10-26 | Same hypothesis, daily bars | 20/100 SMA + ATR stop, 1d | −0.85% | n/a | 4 | **discard** | 2 years of data, 4 trades, PF 0.52. Buy-and-hold over the same period: **+34%** (DD 49%). |
| 2026-10-26 | Is the SMA idea salvageable? | walk-forward, 4 folds, 1d | — | **0 trades** | 0 | **discard** | Out-of-sample: 0 trades, 0/4 folds profitable. Nothing to optimise — the strategy simply doesn't fire on 125-bar training windows. |

---

## What these four runs actually taught us

**1. The benchmark is brutal, and that's fine.** Buy-and-hold on XRP was +5.39% over
4 months and +34% over 2 years — with a 49% drawdown on the way. Any strategy has to
clear that bar *after* fees. A strategy that can't beat "do nothing" is a hobby.

**2. Fees ate the strategy alive.** The SMA crossover made $0.10 on a $250 account while
paying $2.56 in fees. Not "made less than it could have" — **lost money to the exchange
for the privilege of trading.**

**3. The reason is position size, and it's a real finding.** At 0.5% risk with a ~3.8%
stop, each position is about $33 — 13% of the account. That is the *policy working
correctly*. But the SMA strategy only fires 5 times in 4 months, so 5 round trips × 0.8%
on small positions produced noise, not profit.

**4. Exposure was 1.67% of the time.** The strategy was in the market for about 12 hours
out of four months. It wasn't trading. It was occasionally poking the market.

**5. The out-of-sample result is the honest one: zero trades.** Walk-forward says there
is nothing here to optimise. That is a *complete* answer — the fastest way to kill a
bad idea is a walk-forward that produces no trades.

### What to do next (in this order)

- [ ] **Don't tune the SMA parameters.** Optimising a 4-trade strategy is how you fit
      noise. Log it as dead and move on.
- [ ] **Try a higher-frequency hypothesis** — one that actually trades, so the sample
      size can reach 30. More trades = more fees, so the edge has to clear 3.2%.
- [ ] **Consider whether 0.5% risk is right for a $250 account.** It's very conservative.
      At 1%, a $250 account risks $2.50 per trade. The risk policy says Max decides —
      this is a question for him, not for the agent.
- [ ] **Get more history.** Kraken's public OHLC gives 720 daily candles. Download
      CSVs from CryptoDataDownload for 5+ years so strategies have a real sample.
- [ ] **Test on a second pair.** An edge that only exists on XRP is a coin story, not a
      strategy.

---

## Rules

- Change **one** thing at a time. Two changes at once teaches you nothing.
- Record the hypothesis before you run it, not after.
- A discarded experiment stays in the table. Delete nothing.
- If a result looks too good, treat it as a bug until proven otherwise: check for
  lookahead, survivorship bias, and unrealistic fills before you believe it.
- **Fees are part of the result.** A strategy that only looks good at 0% fees does not
  look good.
