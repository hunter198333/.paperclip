# Risk Policy — Digitraders

**Owner:** Max (human), enforced by the Risk and Ops agent
**Last updated:** 2026-10-25
**Exchange:** Kraken (Pro spot)
**Applies to:** every trade, live or paper, proposed by any agent

> This file is the law. The Risk and Ops agent checks every proposal against it and
> outputs a `RISK CHECK: PASS` / `FAIL` line. The Desk Manager cannot override a FAIL.
> Only Max changes this file, and every change gets a line in `docs/decisions/`.

---

## 0. Your capital

| | |
|---|---|
| **Exchange** | Kraken (Pro spot) |
| **Starting capital** | **$250.00** (confirmed) |
| **Weekly contribution** | **+$100.00 per payday** — planned, not optional |
| **Capital by Christmas (≈7 deposits)** | **~$950** |
| **Fee tier** | Tier 1 (30-day volume $0+) |
| **Kraken spot fees** | **0.40% maker / 0.80% taker** (raised 2026-07-09) |
| **Round-trip cost (maker limit order)** | **0.80% of notional** |
| **Round-trip cost (taker market order)** | **1.60% of notional** |

**Capital rule:** money needed for living expenses — bills, the car, tires, the
alignment — is **not trading capital** and is never treated as available. If a trade
would eat into it, the trade doesn't happen.

### 0.1 The plan, stated honestly

The account grows from **$250 to roughly $950 by Christmas because of deposits**, not
because of trading. That's the plan, and it's a good one — contributions compound
without a single losing trade.

**Trading P&L is the bonus, and it is measured separately.** The paper status always
shows three numbers, and they must never be confused:

| Number | What it is |
|---|---|
| **Capital in the account** | $250 + every deposit. Not performance. |
| **Trading P&L** | What the desk actually made or lost. **This is the only number that measures the desk.** |
| **Total equity** | Capital in + trading P&L. What the account is worth. |

A growing account with flat trading P&L means the desk isn't working yet. Report it
that way, every time.

### 0.2 Read this before you size anything

At $250, a **full-account round trip costs $2 (maker) or $4 (taker) in fees alone.**
That is 0.8%–1.6% of the account burned before the trade has any chance of working.

Three consequences, and they drive every limit below:

1. **A strategy needs ≥3.2% gross edge just to break even** (maker). At taker rates it
   needs ≥6.4%. Most intraday crypto edges don't clear that at this size.
2. **Fees, not the strategy, are the biggest cost line.** Sizing discipline beats
   "finding a better signal" at this capital level.
3. **Therefore: paper trade until the edge is measured, use maker orders only, and
   keep daily traded notional small.** The rig and the learning are the deliverable
   right now. The P&L is the lab fee.

### 0.3 Deposits are logged, never improvised

Every contribution is recorded with a date and amount:

```bash
bash scripts/paper-cycle.sh --deposit 100 --note "payday 2026-11-07"
```

That writes to `docs/trading/capital.md` and re-sizes the paper account from that
date forward. Agents may record a deposit when Max tells them about one — they may
**never** invent one, adjust one, or remove one.

Because every limit here is a **percentage**, the limits scale with the account as it
grows. $0.5% risk is $1.25 at $250 and $4.75 at $950 — no re-writing needed.

---

## 1. Limits

Fill in the "Your value" column when you decide. Until then, the defaults apply.

| # | Limit | Default | Your value |
|---|---|---|---|
| L1 | Max risk per trade (loss at stop, % of equity) | **0.5%** | *(scales as the account grows)* |
| L2 | Max total open risk across all positions | **2.0%** | |
| L3 | Max daily loss → **desk stops for the day** | **2.0%** | |
| L4 | Max drawdown from equity peak → **desk stops** | **10%** | |
| L5 | Max leverage | **1x** (spot, no margin) | |
| L6 | Max single position notional | **25% of equity** | |
| L7 | Max concurrent open positions | **3** | |
| L8 | Max positions in the same direction on correlated assets | **2** | |
| L9 | Min liquidity: order size as % of 1h volume | **< 0.5%** | |
| L10 | Min stop distance (ATR multiples on the trading timeframe) | **1.5 × ATR(14)** | |
| L11 | Consecutive stop-outs before a session pause | **2** | |
| L12 | Min backtest trades before a strategy may go live | **30** | |
| L13 | **Cost-to-edge ratio** — round-trip fees ≤ 25% of expected gross edge | **mandatory** | |
| L14 | **Max daily traded notional** (sum of all orders, both sides) | **2× equity** | |
| L15 | **Maker orders only** — limit, post-only. Market orders are rejected. | **mandatory** | |
| L16 | Max open risk as % of equity across a rolling 7 days | **5%** | |

### What L13–L15 mean in practice

| Rule | Maker (limit) | Taker (market) |
|---|---|---|
| Round-trip fee | 0.80% | 1.60% |
| Minimum gross edge to satisfy L13 | **3.2%** | 6.4% (and L15 forbids it) |
| Fee on a $250 position | $2.00 | $4.00 |
| Fee on a $100 position | $0.80 | $1.60 |

`scripts/position-size.sh` does this arithmetic for you — run it before any proposal.

---

## 2. Approval chain

No live trade without all four, in order:

```
1. Thesis      (Market Analyst)      → docs/research/<date>-<slug>.md
2. Proposal    (Desk Manager)        → docs/trading/journal/<date>-<slug>.md
3. Risk check  (Risk and Ops)        → RISK CHECK: PASS on the proposal
4. Human sign-off (Max)              → explicit approval on the Paperclip issue
```

**Silence is not approval.** Only the paper path runs without step 4.

---

## 3. Mode

The desk has two modes, stored in `.paperclip/trading.mode`:

| Mode | Meaning | Who sets it |
|---|---|---|
| `paper` | Simulated fills only. No real orders, ever. | Default. Any time. |
| `live` | Real orders allowed — **still only after step 4** | Max only |

```bash
bash scripts/trading-mode.sh show      # current mode
bash scripts/trading-mode.sh paper     # back to paper (safe, instant)
bash scripts/trading-mode.sh live      # requires typing the confirm phrase
```

Every agent reads this file before proposing execution. In `paper` mode, the order
layer must be **unable** to reach a live endpoint — and there must be a test proving it.

---

## 4. Hard stops

Any one of these stops the desk immediately. No new positions until Max writes a decision
in `docs/decisions/`:

- Daily loss limit reached (L3)
- Max drawdown breached (L4)
- Two consecutive stop-outs (L11)
- A live order was found without a recorded approval
- Exchange API errors, or a position that doesn't reconcile with Kraken
- An agent asks for withdrawal permissions or tries to move funds off Kraken
- **Kraken's account or API becomes unavailable** — no "try again later" trading on a
  broken feed

---

## 5. Position sizing

The only sizing rule: **risk per trade = distance to stop × size**, within L1.

```
risk_amount  = |entry − stop| × size
risk_percent = risk_amount / equity × 100
```

If `risk_percent > L1`, the **size** is wrong — not the limit. Size down or tighten the
setup; never raise the limit to fit the trade.

Always run:

```bash
bash scripts/position-size.sh --equity 250 --entry 1.85 --stop 1.78 --risk 0.5
```

It prints size, notional, risk, and the fee check against L13.

---

## 6. Execution rules

- **Stop loss on every position.** No stop = not a proposal, it's a hope.
- **Maker orders only (L15).** Use limit orders, post-only. A market order burns 0.8%
  more per round trip and is the fastest way to lose money at this size.
- **No averaging down.** Adding to a loser needs explicit human approval, in writing.
- **Never move a stop further away.** Tightening is fine; widening is forbidden.
- **Never add leverage to "recover" a loss.** The single most common way desks die.
- **Idempotency key on every order** so a retry can't double-fill.
- **Never blind-retry an ambiguous order.** Query Kraken for the real position first.
- **Never chase.** If entry moved away from the proposal, the proposal is stale.
- **Check Kraken's minimum order size** for the pair before proposing:
  https://support.kraken.com/hc/en-us/articles/205893708-Minimum-order-size-volume-for-trading
  If the minimum is bigger than your risk budget allows, **don't trade that pair.**
- **Spot only.** Kraken Futures (perps) are a separate account with separate keys and
  separate margin rules. Not in scope, and not at this capital level.

---

## 7. API key rules (Kraken)

- **Never enable "Withdraw Funds" or "Deposit Funds" on a trading key.** The trading
  permission set is: `Query Funds`, `Query Open Orders & Trades`,
  `Create & Modify Orders`, `Cancel/Close Orders`.
- **IP allowlist** the key if the host has a stable IP. A phone on mobile data doesn't —
  which is an argument for running execution from a fixed host.
- **Separate key per agent/workspace.** The research workspace gets a **read-only** key
  (`Query Funds` + `Query Open Orders & Trades`) or none at all.
- **Keys live in Paperclip secrets**, never in a file, never in git, never in a log:

  ```bash
  export KRAKEN_API_KEY='...'
  export KRAKEN_API_SECRET='...'
  npx paperclipai secrets create --company-id <company-id> \
    --name kraken-api-key --value-env KRAKEN_API_KEY
  ```

- **Never print a key.** Not in a commit message, an issue comment, a backtest log, or
  a support question. If one leaks, revoke it immediately and write it up in
  `docs/decisions/`.
- **WebSocket note:** private WS channels need the `Get WebSocket Token` permission and
  a short-lived token (15 min) — don't try to use the API key directly on the socket.

---

## 8. What agents may never do

- Place a live order without the full four-step approval chain
- Use a market order (L15) or any order type that takes fees above maker
- Request, enable, or use withdrawal or deposit permissions
- Modify this file (only Max edits it)
- Change limits inside code instead of here
- Place an order in `paper` mode
- Report a P&L, drawdown, or balance number it did not read from a source
- Recommend a higher-risk trade to offset a loss
- Delete or edit trade journal entries (corrections are append-only)
- Backdate a journal entry
- Trade a pair whose minimum order size exceeds the position budget

---

## 9. Change log

| Date | Change | By |
|---|---|---|
| 2026-10-25 | Initial policy, conservative defaults, Kraken Tier-1 fee model | Mavis (for Max) |
| 2026-11-02 | Capital confirmed: $250 start + $100/week deposits. Added deposit-vs-P&L separation and the capital ledger. | Mavis (for Max) |
