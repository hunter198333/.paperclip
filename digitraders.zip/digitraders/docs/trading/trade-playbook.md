# Trade Playbook

The procedure from "we have an idea" to "it's in the journal". Follow it in order. Every
step has an artifact, and the artifact is what the next agent reads.

---

## Step 0 — Mode check

```bash
bash scripts/trading-mode.sh show
```

If the output is `paper`, everything below produces **paper results only**. That's fine —
that's where you should be for months.

---

## Step 1 — Thesis (Market Analyst)

**Artifact:** `docs/research/<YYYY-MM-DD>-<slug>.md`

- The question, the hypothesis, the data used, the sample size
- The edge, stated in one sentence
- The conditions under which it's wrong

**Exit condition:** the analyst has found a setup worth pricing, *or* has clearly shown
there isn't one. Both are good outcomes. "It might work" is not.

---

## Step 2 — Strategy + backtest (Quant Developer)

**Artifact:** code + PR in `workspaces/engine/`, results in the PR

Required numbers: total trades, win rate, profit factor, max drawdown, average R, worst
trade, out-of-sample result.

**Exit condition:** out-of-sample result exists, trade count ≥ L12 (default 30), no
lookahead, costs included.

If the backtest is bad, **stop here**. A negative result is a complete, useful outcome.
Do not tune until it looks good — that's overfitting, and the experiment log will show it.

---

## Step 3 — Proposal (Desk Manager)

**Artifact:** `docs/trading/journal/<YYYY-MM-DD>-<slug>.md` (copy `template.md`)

Fill in: instrument, side, entry, stop, target, size, risk %, thesis link, invalidation,
exit conditions, and the mode.

**Exit condition:** the proposal is complete enough that another agent could place it
without asking a question.

---

## Step 4 — Risk check (Risk and Ops)

**Artifact:** a `RISK CHECK: PASS` or `RISK CHECK: FAIL` comment on the proposal file.

The check enumerates all 11 checks from `docs/trading/risk-policy.md` with actual numbers.

**Exit condition:** `PASS`. A `FAIL` is not negotiable by the Desk Manager. Fix the
proposal or escalate to Max.

---

## Step 5 — Human approval

**Artifact:** an explicit approval comment on the Paperclip issue, from Max.

The request must contain:
- what exactly will be traded (instrument, side, size, entry, stop)
- the maximum loss if it goes wrong, in money and percent
- what the agent should do if the entry doesn't fill
- the mode it applies to

**Exit condition:** Max says yes, in those terms. **Silence, a thumbs-up on a summary, or
"looks good buddy" is not approval** — if the trade details aren't restated and agreed,
it isn't approved.

---

## Step 6 — Execute (Quant Developer)

- Place **one** order. The exact one that was approved — same instrument, same side, same
  size, same stop.
- Use an idempotency key.
- Attach the stop immediately after the fill, without exception.
- Log the exchange order ID and the actual fill price in the journal entry.

**Exit condition:** the fill is confirmed *by querying the exchange*, not by trusting the
response. If the state is ambiguous, query — never blind-retry.

---

## Step 7 — Journal (Risk and Ops)

Update the journal entry with: fill price, size, fees, order ID, timestamp, and the
running position. Append-only — corrections are new lines, never edits.

Update `docs/status-board.md`.

---

## Step 8 — Manage and exit

- The exit rule (stop, target, or thesis invalidation) is written in the proposal
  **before** entry. Changing it later needs a new approval.
- If the thesis is invalidated before the stop hits: closing early is a human decision.
- If the stop hits: log it, don't touch it, count it toward L11.

---

## Step 9 — Review

Weekly:
- Which thesis held, which didn't?
- Did we follow the rules, or did we talk ourselves into something?
- Slippage vs plan — why did fills differ?
- What did the experiment log teach us?

The point of the journal is that after three months you can actually see whether the edge
is real, or whether you were just lucky once.
