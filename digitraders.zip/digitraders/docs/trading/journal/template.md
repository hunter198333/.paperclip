# Trade Proposal — <INSTRUMENT> — <short slug>

**Date:** YYYY-MM-DD
**Instrument:** <!-- e.g. BTC/USDT perpetual -->
**Side:** <!-- LONG | SHORT -->
**Mode:** <!-- paper | live — read from .paperclip/trading.mode -->
**Proposed by:** <!-- Desk Manager -->
**Risk checked by:** <!-- Risk and Ops -->
**Approved by:** <!-- Max, with date. Blank = NOT APPROVED -->

---

## Thesis

<!-- One paragraph: what you believe, and why now. Link the research note. -->

**Research note:** `docs/research/YYYY-MM-DD-<slug>.md`

## Levels

| | |
|---|---|
| **Entry** | |
| **Stop** | |
| **Target** | |
| **Risk:reward** | |
| **Size (units)** | |
| **Notional** | |
| **Risk amount** | |
| **Risk % of equity** | <!-- must be ≤ L1 in the risk policy --> |
| **Timeframe** | |
| **Stop distance in ATR(14)** | <!-- must be ≥ L10 --> |
| **Order size as % of 1h volume** | <!-- must be < L9 --> |

## Invalidation

<!-- The condition that proves the thesis wrong, stated before entry. -->

## Exit rules

- **Stop:** <!-- exact price -->
- **Target:** <!-- exact price -->
- **Time stop:** <!-- if no movement in X, exit — say so -->
- **Early exit:** <!-- conditions, if any -->

## Execution notes

- <!-- Anything the executor must know: slippage assumptions, partial fills, funding -->

## Checklist before execution

- [ ] Backtest exists with out-of-sample result and ≥ 30 trades
- [ ] Risk check: PASS
- [ ] Human approval recorded above
- [ ] Mode confirmed
- [ ] Stop loss will be attached immediately after fill
- [ ] Idempotency key used

---

## Execution record

<!-- Filled in after execution, by whoever executed it. -->

| | |
|---|---|
| **Order ID** | |
| **Filled at** | |
| **Size filled** | |
| **Fees** | |
| **Filled at (UTC)** | |
| **Confirmed by query?** | <!-- yes/no — query the exchange, don't trust the response --> |

## Outcome

<!-- After the trade closes: R multiple, what actually happened, and one honest sentence
     about whether the thesis or the process was wrong. -->
