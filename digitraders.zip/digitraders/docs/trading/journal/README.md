# Trade Journal

One file per proposal/trade: `<YYYY-MM-DD>-<instrument>-<slug>.md`.

**Append-only.** Corrections are added as new lines with a timestamp. Nothing is ever
edited or deleted — a journal you can rewrite tells you nothing.

A proposal is created in `paper` mode and can be executed later in `live` mode; the mode
at execution time is what gets recorded in the execution section.

## Index

| Date | Instrument | Side | Mode | Result | Link |
|---|---|---|---|---|---|
| | | | | | |

## Rules

- Never edit a past entry. Ever.
- Never backdate.
- One file per trade. No bundling.
- Fill in every field. `unknown` is a valid answer; a blank is not.
- The journal is the only record of what actually happened. The board is a summary of it.
