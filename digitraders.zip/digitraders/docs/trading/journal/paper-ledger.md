# Paper Trade Ledger

Append-only. One row per **closed** paper trade. Written by the paper cycle
(`node src/cli.js paper`). Never edit or delete a row — corrections are new rows.

A paper trade is a simulated fill produced by the same engine that would place a
real one. It is a rehearsal, not a profit.

| Closed (UTC) | Pair | Side | Entry | Exit | Size | P&L | Fees | R | Exit reason |
|---|---|---|---|---|---|---|---|---|---|
