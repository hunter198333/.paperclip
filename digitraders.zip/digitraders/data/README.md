# data/

Scratch space. Git-ignored on purpose.

Put here:
- raw exports (`paperclipai company export --out ./data/export`)
- agent run transcripts and logs
- scratch analysis that hasn't earned a place in `docs/` yet

Nothing in here is durable. If it matters, it belongs in `docs/` or in a workspace.
